#ifndef DAPKN_C_H
#define DAPKN_C_H

#include "types.h"

/* Derives from dEnemyBase_c, on the evidence of its own destructor: `_ZN7daPkn_cD1Ev`
 * stores this vtable, destroys six members, then calls `dEnemyBase_c::~dEnemyBase_c`.
 *
 * The members close exactly on one another, and dEnemyBase_c's own 0x110 closes
 * exactly on the first:
 *
 *     0x110 ModelAnim     0x64   -> 0x174
 *     0x174 Model         0x50   -> 0x1c4
 *     0x1c4 dBgCh_Actr    0x1bc  -> 0x380
 *     0x380 dCcAc_c       0x34   -> 0x3b4
 *     0x3b4 dCcAc_c       0x34   -> 0x3e8
 *     0x3e8 dCcAcPos_c    0x40   -> 0x428
 *
 * The dExtFrameCtrl_c base of mModelAnim sits at 0x160 and mModelAnim.file at 0x170.
 *
 * SIZE IS THE ROM'S OWN, and the observed field span agrees with it:
 * daPkn_c_classInit loads the literal 0x47c from ov084 0x0213016c and hands it
 * to fBase_c::operator new, and the last touched word (0x478) closes on 0x47c.
 *
 * THE NAME IS THE CARTRIDGE'S OWN. ov084 0x02130bec holds the bytes
 * "7daPkn_c\0" -- the length-prefixed mangled type name -- _ZTI7daPkn_c at
 * 0x02130bf8 points its +4 word back at that string, and the vtable's -4 header
 * word at 0x02130c24 points back at the _ZTI. The factory daPkn_c_classInit
 * (historical alias PiranhaPlant_Spawn) constructs it for the PAKUN registry
 * profile at 0x02130c04, whose id is 0xfa.
 */

#include "dEnemyBase_c.h"
#include "ModelAnim.h"
#include "Model.h"
#include "dCcAc_c.h"
#include "dCcAcPos_c.h"
#include "dBgCh_Actr.h"

struct daPkn_c : dEnemyBase_c {
    ModelAnim       mModelAnim;         /* 0x110 */
    Model           mModel;             /* 0x174 -- sleep bubble */
    dBgCh_Actr      mWithMeshClsn;      /* 0x1c4 */
    dCcAc_c         mdCcAc_c1;          /* 0x380 */
    dCcAc_c         mdCcAc_c2;          /* 0x3b4 */
    dCcAcPos_c      mdCcAcPos_c;        /* 0x3e8 -- head, live only in state 2 */
    Vector3         mBubbleScale;       /* 0x428 -- sleep-bubble Model */
    Vector3         mBubblePos;         /* 0x434 -- sleep-bubble world pos */
    Vector3         mHeadClsnOffset;    /* 0x440 -- head cylinder; rewritten every frame */
    Vector3         mHomePos;           /* 0x44c -- spawn point; InitResources copies 0x440 once */
    s32             mState;             /* 0x458 */
    u8              mClsnEnabled;       /* 0x45c */
    /* Field names from here down are coined from how the code uses them. */
    u8              mSubSoundFadedOut;  /* 0x45d -- set once the sub-sound 0x36 fade to 0 is accepted */
    u8              pad_45e[0x2];
    Player         *mClosestPlayer;     /* 0x460 -- dActor_c::ClosestPlayer, refreshed every frame */
    s32             mPlayerDist;        /* 0x464 -- distance to it, 0x7fffffff with none */
    s16             mTargetAngleY;      /* 0x468 -- yaw toward player; rewritten every frame */
    u8              pad_46a[0x2];
    s32             mPlayerAirborne;    /* 0x46c -- copy of its Player::mIsAirborne */
    s32             mParticleHandle;    /* 0x470 */
    s32             mParticleHandle2;   /* 0x474 */
    s32             mLoopSoundHandle;   /* 0x478 -- Sound::PlayLong handle; Behavior zeroes it on a state change */

    /* --- vtable --- */

    /* INLINE, AND DECLARED FIRST. The cartridge puts D1 at 0x0212eaf0 below D0
       at 0x0212eb48 and carries no D2 anywhere, which is what mwccarm 2004/b56
       emits for an inline in-class destructor; the out-of-line form emits
       D2/D0/D1 in the wrong order plus a homeless D2. The typed member list
       above makes the empty body own the dCcAcPos_c, the two dCcAc_c, the
       dBgCh_Actr, the Model and the ModelAnim teardowns in that
       reverse-declaration order, and the chain into _ZN12dEnemyBase_cD2Ev --
       which is exactly what both ROM bodies do.

       With the destructor inline, OnAimedAtWithEgg becomes the first
       out-of-line virtual this class declares -- the key function -- so the
       compiler emits the vtable and the RTTI group into the translation unit
       that defines it, src/game/actors/d_a_pkn.cpp. They do not ship from here:
       ov084 delinks no .data, so text-only isolation discards all three and
       the ROM copies stand -- see compiler_only_output in
       config/tu_manifest.d/ov084/daPkn_c.json. */
    virtual ~daPkn_c() {}

    virtual s32   OnAimedAtWithEgg();      /* slot 29 -- key function */

    int Behavior();
    int CleanupResources();
    int InitResources();
    void OnPendingDestroy();
    int Render();

    /* The nine states Behavior calls through the member-pointer table, in
       state order. All nine names are coined; the ROM keeps none. */
    void StateWait();       /* 0: full size, wait for a player in range */
    void StateSleep();      /* 1: snore until a player comes close */
    void StateBite();       /* 2 */
    void StateWake();       /* 3 */
    void StateDoze();       /* 4: settle back to sleep */
    void StateDie();        /* 5 */
    void StateShrink();     /* 6 */
    void StateGone();       /* 7: hidden until the player leaves */
    void StateRegrow();     /* 8 */

    /* Nonvirtual helpers of the same TU, recovered as members: each takes
       the object as its first parameter in the ROM and only touches this
       class's own state. Formerly free func_ov084_* names (see
       symbols/actor_renames.tsv). */
    void Die();                    /* kills the plant: death anim, state 5 */
    void EnterLunge(int frame);    /* state 2, lunge animation at `frame` */
    void UpdatePose();             /* poses both models, head cyl, bubble */
    int  CheckHits();              /* shared idle hit check; 1 = a hit killed */
    int  PlayerMovingFast();       /* closest player fast enough to wake it? */
    void TrackClosestPlayer();     /* mClosestPlayer/Dist/AngleY/Airborne */
};

#ifndef SM64DS_PLATFORM_PC
/* ROM layout under mwccarm; host ABI divergence is tracked separately. */
typedef char daPkn_c_size_must_be_0x47c[sizeof(daPkn_c) == 0x47c ? 1 : -1];
#endif

#endif /* DAPKN_C_H */
