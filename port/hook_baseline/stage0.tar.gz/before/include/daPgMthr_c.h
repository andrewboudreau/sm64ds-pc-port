/* Seeded from matched-function evidence by tools/gen_header.py, then given its
 * real base and real member types by hand.
 *
 * The ROM RTTI calls this class daPgMthr_c and identifies dActor_c as its base:
 * overlay_0018.bin holds the type-name string `10daPgMthr_c` at 0x02113988, and
 * the type_info record at 0x0211397c points its base word at 0x0208e390, which
 * config/arm9/symbols.txt names _ZTI8dActor_c. The class name here is the
 * cartridge's own spelling, so the compiler-emitted _ZTS reproduces the ROM
 * string exactly rather than a coined one.
 *
 * The destructor is the first virtual declared, and so this class's key
 * function; ov018/daPgMthr_c defines it, and every other override, so mwccarm
 * homes _ZTI/_ZTS/_ZTV in that translation unit.
 *
 * sizeof is independently pinned by daPgMthr_c_classInit allocating 0x38c.
 * Field names for the unknown tail are placeholders. */
#ifndef DAPGMTHR_C_H
#define DAPGMTHR_C_H
#include "types.h"
#include "ModelAnim.h"
#include "TextureSequence.h"
#include "dExtShadowModel_c.h"
#include "dCcAc_c.h"
#include "dBgCh_Actr.h"

#ifdef __cplusplus

#include "dActor_c.h"

struct daPgMthr_c : dActor_c {
    u8  pad_0d0[0x4];
    ModelAnim mModelAnim;            /* 0x0d4 */
    TextureSequence mTextureSequence; /* 0x138 */
    dExtShadowModel_c mShadowModel;        /* 0x14c */
    dCcAc_c mdCcAc_c;                /* 0x174 */
    dBgCh_Actr mWithMeshClsn;        /* 0x1a8 */
    s32 mHomePosX;                   /* 0x364 */
    s32 mHomePosY;                   /* 0x368 */
    s32 mHomePosZ;                   /* 0x36c */
    /* 021123d0 writes data_ov018_02113c4c + (i<<4) here; 02112398/0211235c
       call through it as a PMF pair. */
    void *mState;                    /* 0x370 */
    /* ClosestPlayer / FindWithID result. StartTalk, ShowMessage,
       GetTalkState, DropActor take it as Player. */
    Player *mPlayer;                 /* 0x374 */
    /* 021118fc: last FindWithID hit, so a new PLAYER (0xbf) is noticed. */
    dActor_c *mLastPlayer;           /* 0x378 */
    s32 unk_37c;                     /* 0x37c -- 021122ec/021121dc/02111f1c write 0/1/2; no reader in this TU */
    s16 mLookAngX;                   /* 0x380 -- 02111a48 approaches, 02111d28 applies */
    s16 mLookAngY;                   /* 0x382 */
    s16 mMessageId;                  /* 0x384 -- 0xac / 0xad / 0xae from 02111968 */
    u8  mGaveStar;                   /* 0x386 -- 02111fac sets when spawning POWER_STAR */
    u8  mHoldingBaby;                /* 0x387 -- 02111968, held actorID 0x100 (BABY_PENGUIN) */
    u8  mTalkStep;                   /* 0x388 -- 02111fac 0..3 */
    u8  mTalkTimer;                  /* 0x389 -- 021121dc arms 0x3c; DecIfAbove0_Byte */
    u8  pad_38a[2];

    /* --- vtable overrides. Slots are inherited from fBase_c/dActor_c. --- */
    /* Defined here, in the class body, and not out of line in the .cpp: the
     * cartridge keeps D1 (0x02111848) BELOW D0 (0x02111898), and an out-of-line
     * member definition makes mwccarm emit the D2/D1/D0 group in the order
     * D0-then-D1, which the whole-range link refuses (`licensed .text functions
     * are not emitted in ROM address order`). Written in the class body the
     * group comes out ROM-ascending, and no D2 is emitted at all. The body is
     * genuinely empty -- every store and call in the two ROM bodies is base and
     * member destruction the compiler generates. Slots 16 (D1), 17 (D0). */
    virtual ~daPgMthr_c() {}
    virtual int InitResources();                 /* slot 0 */
    virtual int CleanupResources();              /* slot 3 */
    virtual int Behavior();                      /* slot 6 */
    virtual int Render();                        /* slot 9 */
    virtual void OnPendingDestroy();             /* slot 12 */

    void func_ov018_02111968(void *found, char *heldRaw);
    void func_ov018_02111a48(char *b);
    void func_ov018_02111b3c();
    void func_ov018_02111d28();
    int func_ov018_02111e28();
    int func_ov018_02111f1c();
    int func_ov018_02111fac();
    int func_ov018_021121dc();
    int func_ov018_02112234();
    int func_ov018_021122ec();
    void func_ov018_021123d0(int i);
};

#ifndef SM64DS_PLATFORM_PC
/* ROM layout under mwccarm; host ABI divergence is tracked separately. */
typedef char MotherPenguin_size_must_be_0x38c[sizeof(daPgMthr_c) == 0x38c ? 1 : -1];
#endif

#else

struct daPgMthr_c {
    u8  pad_000[0x5c];
    s32 mPosX;            /* 0x05c */
    s32 mPosY;            /* 0x060 */
    s32 mPosZ;            /* 0x064 */
    u8  pad_068[0x18];
    s32 mScaleX;            /* 0x080 */
    s32 mScaleY;            /* 0x084 */
    s32 mScaleZ;            /* 0x088 */
    u8  pad_08c[0x10];
    s32 mVertAccel;            /* 0x09c */
    s32 mTerminalVelocity;            /* 0x0a0 */
    u8  pad_0a4[0x30];
    /* ModelAnim member, named by _ZN9ModelAnimD1Ev at +0xd4 -- a relocation the ROM build
       checks. D1 and not D2, so it is this type and not an inlined base. The marker's pad
       stopped short of the object, so the member also takes over unk_0dc (+0x8 = data),
       mAnimation (+0x50 = the dExtFrameCtrl_c base), which the header declared separately inside
       it. */
    ModelAnim mModelAnim;            /* 0x0d4 */
    /* TextureSequence member, named by the class's own destructor calling
       TextureSequence's D1 at +0x138 -- a relocation the ROM build
       checks. Was a u8 marker. [_ZN10daPgMthr_cD0Ev, now in src/game/actors/d_a_pg_mthr.cpp] */
    TextureSequence mTextureSequence;            /* 0x138 */
    /* dExtShadowModel_c member, named by the class's own destructor calling
       dExtShadowModel_c's D1 at +0x14c -- a relocation the ROM build
       checks. Was a u8 marker. [_ZN10daPgMthr_cD0Ev, now in src/game/actors/d_a_pg_mthr.cpp] */
    dExtShadowModel_c mShadowModel;            /* 0x14c */
    /* dCcAc_c member, named by the class's own destructor calling
       dCcAc_c's D1 at +0x174 -- a relocation the ROM build
       checks. Was a u8 marker. [_ZN10daPgMthr_cD0Ev, now in src/game/actors/d_a_pg_mthr.cpp] */
    dCcAc_c mdCcAc_c;            /* 0x174 */
    /* dBgCh_Actr member, named by the class's own destructor calling
       dBgCh_Actr's D1 at +0x1a8 -- a relocation the ROM build
       checks. Was a u8 marker. [_ZN10daPgMthr_cD0Ev, now in src/game/actors/d_a_pg_mthr.cpp] */
    dBgCh_Actr mWithMeshClsn;            /* 0x1a8 */
    s32 mHomePosX;            /* 0x364 */
    s32 mHomePosY;            /* 0x368 */
    s32 mHomePosZ;            /* 0x36c */
    void *mState;             /* 0x370 */
    s32 mPlayer;              /* 0x374 */
    s32 mLastPlayer;          /* 0x378 */
    s32 unk_37c;              /* 0x37c */
    s16 mLookAngX;            /* 0x380 */
    s16 mLookAngY;            /* 0x382 */
    s16 mMessageId;           /* 0x384 */
    u8  mGaveStar;            /* 0x386 */
    u8  mHoldingBaby;         /* 0x387 */
    u8  mTalkStep;            /* 0x388 */
    u8  mTalkTimer;           /* 0x389 */
    u8  pad_38a[2];
};

#ifndef SM64DS_PLATFORM_PC
/* ROM layout under mwccarm; host ABI divergence is tracked separately. */
typedef char MotherPenguin_size_must_be_0x38c[sizeof(struct daPgMthr_c) == 0x38c ? 1 : -1];
#endif

#endif /* __cplusplus */

#endif
