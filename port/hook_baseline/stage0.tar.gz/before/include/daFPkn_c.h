#ifndef DAFPKN_C_H
#define DAFPKN_C_H

#include "types.h"

/* Derives from dEnemyBase_c, on the evidence of its own destructor: `_ZN8daFPkn_cD1Ev`
 * stores this vtable, destroys three members, then calls `dEnemyBase_c::~dEnemyBase_c`.
 * Everything this header used to restate below 0x110 belongs to that chain and
 * is inherited now.
 *
 * The members close exactly on one another, and dEnemyBase_c's own 0x110 closes
 * exactly on the first:
 *
 *     0x110 ModelAnim                  0x64   -> 0x174
 *     0x174 dCcAc_c         0x34   -> 0x1a8
 *     0x1a8 dCcAcPos_c  0x40   -> 0x1e8
 *
 * Typing them absorbed these markers, which were a member's insides:
 *   - 0x160 mAnimation   = the dExtFrameCtrl_c base of mModelAnim
 *   - 0x178 unk_178      = mdCcAc_c.radius (+0x04)
 *   - 0x17c unk_17c      = mdCcAc_c.height (+0x08)
 *   - 0x1ac unk_1ac      = mdCcAcPos_c.radius (+0x04)
 *   - 0x1b0 unk_1b0      = mdCcAcPos_c.height (+0x08)
 *
 * SIZE IS THE OBSERVED FIELD SPAN, rounded up. It guards this declaration; it
 * is not independent evidence about the ROM.
 *
 * SM64DS proves this class as daFPkn_c through RTTI, allocation size and
 * vtable identity: _ZTI8daFPkn_c at ov084 0x02130ac0 names "8daFPkn_c" at
 * 0x02130ab4. This header called the class FirePiranhaPlantBig, a readable
 * invention, until the rename that promoted src/game/actors/d_a_f_pkn.cpp. The factory and profile spellings below are reconstructed
 * source-style names -- evidence-bounded proposals, not recovered SM64DS
 * symbols.
 *
 * daFPkn_c_classInit_FIREPAKUN at 0x0212eaa8 (historical alias
 * FirePiranhaPlantBig_Spawn) allocates 0x22c and installs this class's
 * cartridge vtable. It backs the FIREPAKUN registry profile, whose
 * descriptor at 0x02130ae8 is reconstructed as g_profile_FIREPAKUN.
 */

#include "dEnemyBase_c.h"
#include "ModelAnim.h"
#include "Model.h"
#include "dCcAc_c.h"
#include "dCcAcPos_c.h"
#include "dBgCh_Actr.h"

struct daFPkn_c : dEnemyBase_c {
    ModelAnim                    mModelAnim;            /* 0x110 */
    dCcAc_c           mdCcAc_c;   /* 0x174 */
    dCcAcPos_c    mdCcAcPos_c; /* 0x1a8 */
    s32                          mRespawnMode;          /* 0x1e8 */
    s32                          mState;                /* 0x1ec */
    s32                          mGroupLeaderID;        /* 0x1f0 */
    /* Coined field names, from their uses: mMarkedMemberID (the leader's copy
       holds the uniqueID of the last member that emerged under the star
       marker), mSpinSpeed and mSpinCount (the spin after a hit), mEmerged,
       mStarMarkerIdx (the leader's star-marker slot, -1 for none) and the two
       Particle::System handles. */
    s32                          mMarkedMemberID;       /* 0x1f4 */
    Vector3                      mClsnOffset;           /* 0x1f8 */
    s32                          mScale;                /* 0x204 */
    s32                          mClsnRadiusFactor;     /* 0x208 */
    s32                          mClsnHeightFactor;     /* 0x20c */
    s32                          mMaxScale;             /* 0x210 */
    s32                          mScaleRate;            /* 0x214 */
    s16                          mSpinSpeed;            /* 0x218 */
    u8                           mGroupAliveCount;      /* 0x21a */
    u8                           mGroupDefeatedCount;   /* 0x21b */
    u8                           mEmerged;              /* 0x21c */
    u8                           mSpinCount;            /* 0x21d */
    u8                           mSuppressDeathReward;  /* 0x21e */
    u8                           mStarID;               /* 0x21f */
    u8                           mAlive;                /* 0x220 */
    s8                           mStarMarkerIdx;        /* 0x221 */
    u8  pad_222[0x2];
    s32                          mParticleHandle1;      /* 0x224 */
    s32                          mParticleHandle2;      /* 0x228 */

    /* --- vtable --- */
    virtual ~daFPkn_c();

    virtual s32   OnYoshiTryEat();         /* slot 18 */
    virtual void  OnTurnIntoEgg(Player &player); /* slot 19 */
    virtual s32   OnAimedAtWithEgg();      /* slot 29 */

    int Behavior();
    int CleanupResources();
    int InitResources();
    int Render();

    /* Coined names for the nine helpers at 0x0212d2dc..0x0212e554. Behavior
       runs StateInit, StateWait, StateSpit and StateGrow for mState 0..3. */
    void SpawnDeathSmoke();
    void SpawnDeathBurst();
    void OnGroupMemberDefeated();
    void UpdateClsnOffset();
    void CheckClsnHits();
    void StateGrow();
    void StateSpit();
    void StateWait();
    int  StateInit();
};

#ifndef SM64DS_PLATFORM_PC
/* ROM layout under mwccarm; host ABI divergence is tracked separately. */
typedef char daFPkn_c_size_must_be_0x22c[sizeof(daFPkn_c) == 0x22c ? 1 : -1];
#endif

#endif /* DAFPKN_C_H */
