/* Base class for every minigame scene -- 15 direct RTTI children, 32
 * descendants. Field names and widths were recovered from matched bodies;
 * see notes/minigame-provenance.md for the evidence behind each one, and for
 * why the destructor is declared here but defined out of line. */
#ifndef DSCMGBASE_C_H
#define DSCMGBASE_C_H
#include "dScene_c.h"
#include "dGraph_c.h"
#include "dMgState_c.h"
#include "dMgPsOpt_c.h"

/* The live minigame scene: the dScMgBase_c constructor sets it, the destructor clears it. */
struct dScMgBase_c;
extern "C" dScMgBase_c *gMgScene;

struct dScMgBase_c : dScene_c {

    class graphCallback_c;
    dScMgBase_c();
    /* Declared first (key function), and deliberately NOT defined inline:
       descendants call _ZN11dScMgBase_cD2Ev as a real `bl`, and an inline
       body makes every one of them miss. Defined once in
       src/minigames/d_s_mg_base.cpp, which emits D2, D0 and D1.
       MEASURED -- do not move the body up here. */
    virtual ~dScMgBase_c();

    /* Own copy, deliberately: mwcc only inlines a D0 route through the class
       itself or its immediate base, so descendants cannot reach dScene_c's.
       Removing this breaks D0 for all 32 of them. */
    void operator delete(void *ptr) { _ZN6Memory10DeallocateEPvPN5mHeap6Heap_tE(ptr, data_020a0eac); }

    /* --- overrides of dScene_c's own virtuals, same signature, in _ZTV order.
           1, 2, 5, 7, 10 re-override slots dScene_c already gave a body;
           6, 9, 12 are the first override below fBase_c's own default. --- */
    virtual bool BeforeInitResources();                /* slot  1 */
    virtual void AfterInitResources(u32 vfSuccess);    /* slot  2 */
    virtual void AfterCleanupResources(u32 vfSuccess); /* slot  5 */
    virtual s32  Behavior();                           /* slot  6 */
    virtual int  BeforeBehavior();                     /* slot  7 */
    virtual s32  Render();                             /* slot  9 */
    virtual int  BeforeRender();                       /* slot 10 */
    virtual void OnPendingDestroy();                   /* slot 12 */

    /* --- slots 18-35: eighteen further virtuals new at this class. --------

       These are NOT dActor_c's slots. dActor_c hangs off dBase_c directly;
       this class reaches dBase_c through dScene_c. The two are parallel
       extensions that happen to share indices and nothing else.

       NAMES (2026-10-14). The cartridge names no method of this class, so
       every name below is coined from the slot's bodies and callers;
       notes/minigames/names.md gives each one's evidence and confidence.
       Until then slots 18-30 carried dActor_c's method names, copied across
       by slot index (OnYoshiTryEat, OnTurnIntoEgg, OnGroundPounded,
       OnAttacked1/2, OnKicked, OnPushed, OnHitByCannonBlastedChar,
       OnHitByMegaChar, OnHitFromUnderneath, OnAimedAtWithEgg,
       OnAimedAtWithEggReturnVec), and slots 20 and 31-35 were named after
       their vtable offsets (Virtual50, Virtual7C..Virtual8C). The
       `recovered name:` comments the older prose below cites were that same
       index copy, not independent recoveries; they are quoted below under
       the new names.

ALL EIGHTEEN ARE DECLARED (2026-08-31). This class and all 32 of
       its descendants emit their full 36-slot vtables from source; none of
       them is a prefix any more.

       They were declared one slot at a time, lowest first, and that ordering
       is why it worked. mwcc emits a vtable only as long as the slots it has
       been told about, so after declaring 18..k every descendant emitted k+1
       slots -- a byte-exact PREFIX of the cartridge table, never a
       disagreement, so every intermediate commit was shippable. Declaring all
       eighteen at once would instead have written the BASE body into every
       slot a descendant had not yet declared an override for, turning PARTIAL
       into DIFFERS across the whole family. Anything ADDED here from now on
       is past the cartridge's own table and has no such safety net.

       Slot 18 -- MEASURED, not inferred:
         arity: 13 of the 24 independently decompiled descendant overrides read
           r1 and branch on it (dScMgTeresa_c takes an entirely different path
           when it is 0). Twelve unrelated classes do not read a garbage
           register by coincidence. The base's own body ignores it, but a base
           stub proves nothing either way -- an unused argument is simply never
           read -- so only an override that reads a parameter is evidence, and
           that evidence is a LOWER bound on the arity.
         return type: void, MEASURED -- and it corrects the `int` this block
           used to carry, which rested entirely on dScMgCoin_c::StartRound
           ending `return 0;`.  That reasoning does not survive the bytes.
           Coin's tail is

               bl <Mg_GetTopRecord>      ; result lands in r0
               add r1, r4, #0x5000           ; r0 is LIVE, so the address is r1
               str r0, [r1, #0x1d4]
               mov r0, #0                    ; r0 now free -- the constant 0
               str r0, [r1, #0x1c8]

           The address goes to r1 because r0 still held the call's result, not
           because r0 was reserved for a return value, and the trailing
           `mov r0,#0` is the constant being stored to mPhase.  A `return 0;`
           written after it costs nothing, so Coin is byte-identical under
           BOTH spellings and pins neither.

           Six overrides do pin it, and they pin void.  Converting the
           free-function bodies to real members forces the declaration on them,
           and as `int` mwcc reserves r0 and shifts every register at their
           exits by one -- dScMgSlot1_c 3 words of 19, dScMgMemory_c and
           dScMgMemory2_c 5 of 24 each, dScMgRoulette_c 3 of 63,
           dScMgPanel_c 4 of 68, dScMgSlot3_c 84 of 205:

               ROM   add r0, r4, #0x4000 / mov r1, #0 / str r1,[r0,#0x6b4]
               int   add r1, r4, #0x4000 / mov r2, #0 / str r2,[r1,#0x6b4]

           Spelled void all six are byte-exact and the whole 106/106 holds.
           mwcc rejects the halfway position outright -- a void override of an
           int virtual is `differs from virtual base function ... in return
           type only`, an error, not a warning -- so the base and all 31
           declarations move together.  The return type is not part of the
           Itanium mangled name, so no symbol, vtable or config entry moves.
           The base's own ROM body is a lone `bx lr` and sets nothing.
         name: StartRound. dMgState_c calls it with the finished shared
           state's number once a banner has run (state 0 continues the game,
           3 and 0x12 restart it), and games call it with -1 themselves to
           retry after a lost life. Each override resets its round there. */
    virtual void StartRound(int arg);               /* slot 18 */

    /* Slot 19 -- minigame body observations:
         arity: two of the eleven descendant overrides read r1, and both
           COMPARE it against small integer constants rather than
           dereferencing it -- dScMgJump_c does `if (sel == 0)`,
           dScMgBSC_c does `if (mode == 4) ... else if (mode == 5)`.
           The minigame interface models this selector as int. The separate
           actor declaration does not determine this scene contract.
           Dereference-versus-compare is the discriminator whenever a word
           in r1 could be either: both occupy one register, so codegen
           alone cannot separate `Ei` from `ER6Player`.
         return type: int, and this one needs no argument -- the ov004 base
           body ends `return 1;` and all eleven overrides return a value.
         name: CanEndState. Every dMgState_c behaviour handler polls it
           with mState and holds the banner until it returns nonzero; the
           overrides return 0 while their own reaction is still playing. */
    virtual int  CanEndState(int mode);              /* slot 19 */
    /* Slot 20 -- OnNewRecord. Its one caller, dMgState_c state 17 (the
       results screen taken when the new-record flag is set), calls it once,
       120 frames in, as the record banner goes up. The minigame return contract is
       reconstructed as void: the base does nothing, Cup and Sound forward
       to a void component helper, and 3DEsp and Teresa call the void
       FreeGfxSlotsById function. The recorded caller in
       State17_Update discards the result. These bodies reproduce under
       the coherent void declarations with 2004/b56; this does not recover
       the original return-type spelling. The separate dActor_c slot 20
       remains int. See issue #2492 for caller coverage and proof limits. */
    virtual void OnNewRecord();                          /* slot 20 */
    /* Slot 21 -- OnDealDone, a low-confidence name. Its one caller is
       Dealer_StateDeal in unit020bfec0.cpp, the presenter model's
       reaction animation, which calls it on the last repeat of that
       animation. The base is empty; BSC/Card branch on mHudScore, and the two Memory
       overrides forward a component of this scene. These bodies alone do
       not settle the return contract. Keep the existing void declaration;
       the slot-20 caller audit does not establish this slot's signature.
       Prior int/void experiments and separate slot-27/28 observations are
       retained in the original source history cited by issue #2492's handoff. */
    virtual void OnDealDone();                    /* slot 21 */
/* Slot 22 -- OnGraphCallback1: graphCallback_c::GraphCallback1 forwards
   to it (slot 23 is GraphCallback0's, 24 GraphCallback2's, 25
   GraphCallback3's). What dGraph_c's four callbacks are for is not named
   yet; see include/dGraph_c.h.
     overrides: NONE.  Every one of the 32 descendants inherits this slot, so
       this declaration widens 30 emitted tables by a word and adds no other
       file.  A slot with no overrides is the one case where the widened-table
       COUNT is the entire check: nothing else would notice if the base
       declaration failed to take.
     arity: no explicit parameters.  There is no override to read a second
       argument register, so the only evidence is the base body, which reads
       none. An unread parameter would leave no trace either way. The current
       scene declaration has none; the separate actor signature does not
       establish this scene's parameter list.
     return type: int, MEASURED.  The body is `return 1;` -- it sets r0, which
       a `void` function would not, so this one is not a coin-flip the way slot
       21's tail calls were. */
    virtual int  OnGraphCallback1();                        /* slot 22 */
    /* Slot 23 -- OnGraphCallback0, reached from graphCallback_c::GraphCallback0.
         arity: no explicit parameters, MEASURED.  The base body reads no
           argument register at all, and none of the three overrides touches
           a second one. This supports the current scene declaration; the
           separate actor hierarchy does not determine its parameters.
           The two flat-C callers do not even agree on a
           prototype -- dScMgSnowball_c hands the base a `void *`,
           dScMgTrampoline2_c calls it with nothing -- which is only
           possible because the callee ignores both.  That is corroboration,
           not the measurement.
         return type: int, MEASURED twice.  The base body is `return 1;`,
           and dScMgTrampoline2_c's override has four early `return 0;`
           paths and a final `return 1;`. These scene bodies support int;
           no actor declaration is needed for that conclusion. */
    virtual int  OnGraphCallback0();                        /* slot 23 */
    /* Slot 24 -- OnGraphCallback2, reached from graphCallback_c::GraphCallback2.
       The base body is where the menu's screen is saved and restored on an
       edge of mMenuOpen.
         arity: no explicit parameters, MEASURED.  The base body reads only
           `this`, and so does every override.  No body touches a second
           argument register and every call in the chain passes one pointer
           and nothing else. The current scene declaration has no explicit
           parameters; this does not judge the separate actor interface.
         return type: int, MEASURED from these scene bodies. The base ends
           `return 1;`.  dScMgD3DBase_c, dScMgTrampoline_c and
           dScMgTrampoline2_c each guard on the result of the call to their
           own base and `return 0` early -- the early-return shape that is
           the only thing separating `int` from `void` -- and
           dScMgSnowball_c returns `<base call> != 0`, which cannot be
           written at all against a void callee.  Four independent
           witnesses support int for this hierarchy. The separate actor
           slot at the same index does not determine this contract.
         overrides: SIX tables, FOUR declarations.  dScMgJump_c and
           dScMgJump2_c point at dScMgD3DBase_c's own body (0x020e6e78) and
           override nothing themselves, so declaring it on their shared base
           is what reproduces their slots; a declaration on either child
           would invent an override the cartridge does not have.  The bodies
           spell the chain out themselves -- Trampoline and Trampoline2 both
           call 0x020e6e78, which calls the base's 0x020ae140.
         NAME CORRECTION: 0x020e6e78 carried `recovered name:
           dScMgJump2_c_OnGraphCallback2`.  It is dScMgD3DBase_c's.  A body that
           appears in a class's table AND in both its children's is supplied
           by that class; the recovered name was assigned from one child's
           table without looking at the other two. */
    virtual int  OnGraphCallback2();                           /* slot 24 */
    /* Slot 25 -- OnGraphCallback3, reached from graphCallback_c::GraphCallback3.
         arity: no explicit parameters, MEASURED.  The base body reads one
           field of `this` and nothing else, and all five overrides are a
           single call passing that same one pointer through.  No body
           touches a second argument register. This supports the current
           scene declaration, independently of the actor parameter list.
         return type: int, MEASURED, and not a coin flip: the base body is
           `return mMenuOpen == 0;`, which computes a value into r0 -- a
           `void` function would not.  Every one of the five overrides then
           writes `<base call> != 0`, which cannot be written at all against
           a void callee. These six scene bodies support the int contract;
           an actor declaration at the same index is not additional proof.
         overrides: SEVEN tables, FIVE declarations.  dScMgJump_c and
           dScMgJump2_c point at dScMgD3DBase_c's own body (0x020e6e54) and
           override nothing themselves, exactly as at slot 24, so the
           declaration goes on their shared base and neither child gets one.
           dScMgSmartball_c is new here -- it inherits 22, 23 and 24 and
           overrides 25 -- which is why the override set is read off the ROM
           for every slot rather than carried forward from the last one.
         NAME CORRECTION, the second on this class: 0x020e6e54 carried
           `recovered name: dScMgJump2_c_OnGraphCallback3`.  It is
           dScMgD3DBase_c's, on the same argument that settled 0x020e6e78 at
           slot 24 -- word 25 of _ZTV14dScMgD3DBase_c, _ZTV11dScMgJump_c and
           _ZTV12dScMgJump2_c all point here, and a body in a class's table
           AND in both its children's is supplied by that class.  Both
           misattributions name dScMgJump2_c, which is what a recovery pass
           reading tables in name order would produce. */
    virtual int  OnGraphCallback3();                           /* slot 25 */
    /* Slot 26 -- GetDisplayMode: 0 for this base, 1 for dScMgSingle3DBase_c,
       2 for dScMgD3DBase_c. BeforeInitResources picks the display engines
       from it and the sprite wrappers pick a screen.
         return type: int, MEASURED THREE TIMES, and this is the strongest
           return-type evidence the campaign has had.  The three bodies are
           three DIFFERENT constants -- ov004:0x020b04e0 is `mov r0,#0; bx lr`,
           dScMgSingle3DBase_c's ov006:0x0210a600 is `mov r0,#1`, and
           dScMgD3DBase_c's ov006:0x020e6e4c is `mov r0,#2`.  A void function
           cannot return three different values, and the callers have to be
           able to tell them apart. This is evidence from the scene family.
         arity: no explicit parameters, MEASURED.  All three bodies are two
           instructions and read NO argument register at all -- not even
           `this`. The current scene declaration has no explicit parameters.
           Unread arguments cannot be excluded by these bodies alone; the
           separate actor parameter list does not resolve that uncertainty.
         overrides: NINETEEN tables, TWO declarations -- the widest gap in the
           campaign, and the one slot where the table count would have been
           badly misleading on its own.  The RTTI graph is what closes it:
           dScMgSingle3DBase_c is the shared base of thirteen of those tables
           and dScMgD3DBase_c of four more (build/rtti.json, every edge at
           offset 0), so seventeen classes point at an ancestor's body and
           declare nothing themselves.  Declaring the slot on any of the
           seventeen would invent an override the cartridge does not have.
         NAME CORRECTION, the third on dScMgD3DBase_c: 0x020e6e4c carried
           `recovered name: dScMgTrampoline2_c_GetDisplayMode`.
           Five tables reference it -- dScMgD3DBase_c's and all four of its
           children's -- so it is dScMgD3DBase_c's.  This one also disposes of
           a guess made when reviewing slot 25: that the two earlier
           misattributions both landing on dScMgJump2_c meant a recovery pass
           reading tables in name order.  This one names dScMgTrampoline2_c,
           so whatever the pass did, it was not that.
         The matching error one level down was already found and corrected in
           src/actors/dScMgSingle3DBase_c.cpp: 0x0210a600 had been recovered
           as dScMgFlower_c's.  Three of the same mistake on this one slot is
           what a per-table name assignment produces whenever a body is shared,
           and it is why every slot in this campaign reconciles DISTINCT
           ADDRESSES against declarations and the table count separately. */
    virtual int  GetDisplayMode();           /* slot 26 */
    /* Slot 27 -- OpenMenu: opens the three-item pause menu (BeforeBehavior
       calls it on A, B, Select or Start with the stylus up).
         return type: void, supported by the scene bodies described here.
           ov004:0x020af27c takes an early exit at 0x020af290 --
           `popne {r4,lr}; bxne lr` -- with r0 still holding the field it has
           just loaded and tested, and nothing sets a return value on either
           path out.
         arity: no explicit parameters, MEASURED TWICE, and it matters more
           here than at any other slot.  Both real bodies open `mov r4, r0` and
           then WRITE r1 before ever reading it -- the base fills the menu-item
           coordinates through r1 from 0x020af2a0 onwards, and dScMgSlot1_c's
           override at ov006:0x0210c4dc zeroes r0/r1 for SetSubBg1Offset.  No
           second argument register is live on entry to either.  dActor_c.h:144
           spells `Player &player` and include/dScMgSlot1_c.h had copied it.
         overrides: SIX tables, TWO declarations.  dScMgD3DBase_c's own body at
           ov006:0x020e6d98 backs its table and all four of its children's;
           dScMgSlot1_c has its own at ov006:0x0210c4dc.
         THE RECONCILIATION, and the reason this slot is not the shape of the
           twenty-six before it.  dScMgSlot1_c already carried this member,
           declared as a NEW virtual with dActor_c.h's parameter list and
           landing on index 27 by arithmetic because the base stopped at 26.
           Declaring it here without touching that header would have made the
           two DIFFERENT functions: this one would take 27, dScMgSlot1_c's
           would become a new slot at 28, CloseMenu would be pushed
           to 29, and _ZTV12dScMgSlot1_c would go straight back to DIFFERS --
           with rombuild green throughout.  Both declarations change in this
           one commit, and romdata_check is what says they were reconciled.
         NAME CORRECTION, the fourth on dScMgD3DBase_c and the fifth in this
           campaign: 0x020e6d98 carried
           `recovered name: dScMgTrampoline2_c_OpenMenu`.  Five tables
           reference it -- dScMgD3DBase_c's and all four of its children's --
           so it is dScMgD3DBase_c's.  Its twelve bytes are a long-branch
           veneer into this class's own body, which is what a forwarding
           override compiles to from ov006; the vtable word is NOT a linker
           artifact, because the twenty-six tables that do not override this
           slot hold 0x020af27c directly. */
    virtual void OpenMenu();                    /* slot 27 */
    /* Slot 28 -- CloseMenu: closes the pause menu (its resume item, or a
       button press with nothing highlighted).
         return type: int is the current reconstruction; these bodies do
           not establish an original return type. ov004:0x020af04c leaves
           r0 holding whatever it last tested or
           last called: the early exit at
           `cmp r0,#0; popeq {r4,lr}; bxeq lr` returns the zero it has just
           compared, and the fall-through returns whatever Enable3dEngines
           left.  Neither is a deliberate result.  Nor does any caller settle
           it.  ov004 and ov006 hold exactly three
           `ldr rN,[rM,#0x70]; blx rN` dispatch sites: 0x020aedec and
           0x020aee90 inside Mg_UpdateMenu, and 0x020b06cc inside
           dScMgBase_c::BeforeBehavior.  The first two are tail calls --
           `blx r1; add sp,sp,#0x10; pop {r4,lr}; bx lr` -- which hand r0 back
           to their own caller without ever reading it, and the third branches
           to a shared epilogue that overwrites r0 with `add r0,r4,#0x4000`
           before anything can use it.  Three sites, three discarded results.
           The historical local int/void experiment produced the same bytes.
           The actor signature does not resolve the scene's return contract;
           no declaration is changed by this comment correction.
         arity: no explicit parameters, MEASURED ONCE rather than twice.  The
           base body opens `mov r4, r0` and then writes r1 with
           `add r1, r4, #0x4000` before ever reading it, and reads no other
           argument register anywhere.  dScMgSlot1_c's override at
           ov006:0x0210c4b8 cannot corroborate it the way its slot-27 override
           did: it calls this body as its very first act, so a second argument
           would pass through r1 untouched and leave no trace either way.
           dActor_c.h:145 spells `dActor_c &other` and include/dScMgSlot1_c.h
           had copied it.
         overrides: SIX tables, TWO declarations -- the same shape as slot 27.
           dScMgD3DBase_c's own body at ov006:0x020e6d8c backs its table and
           all four of its children's; dScMgSlot1_c has its own at
           ov006:0x0210c4b8.
         THE RECONCILIATION, for the second and last time in this class.
           dScMgSlot1_c already carried this member, declared as a NEW virtual
           with dActor_c.h's parameter list and landing on index 28 by
           arithmetic because the base stopped at 27.  Declaring it here
           without touching that header would have made the two DIFFERENT
           functions: this one takes 28, dScMgSlot1_c's becomes a new slot at
           29, and _ZTV12dScMgSlot1_c goes straight back to DIFFERS -- with
           rombuild green throughout.  Both declarations change in this one
           commit.  dScMgSlot1_c now declares nothing mwcc has to number for
           itself, so this is the last time the trap is loaded THERE; it can
           still be loaded anywhere else a descendant declared a base slot
           early, which is the one thing to check before each of slots 29-35.
         NAME CORRECTION, the fifth on dScMgD3DBase_c and the sixth in this
           campaign: 0x020e6d8c carried
           `recovered name: dScMgTrampoline2_c_CloseMenu`.  Five
           tables reference it -- dScMgD3DBase_c's and all four of its
           children's -- so it is dScMgD3DBase_c's.  Its twelve bytes are a
           long-branch veneer into this class's own body, `ldr ip, [pc];
           bx ip; .word 0x020af04c`, which is what a forwarding override
           compiles to from ov006; the vtable word is NOT a linker artifact,
           because the twenty-six tables that do not override this slot hold
           0x020af04c directly. */
    virtual int  CloseMenu();                /* slot 28 */
    /* Slot 29 -- SaveScreenForMenu (formerly OnAimedAtWithEgg, dActor_c.h:146
       at the same index). This is the slot that disproved the borrowed
       names; see the caution below.
         return type: int remains an unproved reconstruction, as at slot 28.
           ov004:0x020af094 has
           two exits and neither sets a result: the early one is
           `cmp r0,#2; addeq sp,sp,#8; popeq {r4-r8,lr}; bxeq lr`, returning
           the 2 it has just compared against slot 26's result, and the
           fall-through returns whatever MultiCopy_Int last left in r0.
           No caller settles it either, and here that is MEASURED rather than
           assumed.  Scanning arm9 and all 103 overlays for the dispatch
           pattern -- `ldr rN,[rM,#0x74]` immediately followed by `blx rN`,
           not any load at +0x74, which also matches an ordinary field read --
           finds 35 sites, of which exactly ONE lies in ov004 or ov006, the
           two modules this class and all thirty-two of its descendants live
           in.  That one is ov004:0x020ae178, inside dScMgBase_c::OnGraphCallback2
           (slot 24), and the instruction after the `blx` is
           `add r0,r4,#0x4000`: the result is dead before anything can read
           it, and OnGraphCallback2 goes on to return a literal 1.  The other
           thirty-four sites are in ov025, ov071, ov077, ov079, ov081, ov091,
           ov096 and ov100 -- enemy overlays, dActor_c's branch -- which is
           the sharpest measurement yet of how little the shared index means.
         arity: no explicit parameters, MEASURED THREE TIMES, and the third
           witness is destructive rather than circumstantial.  The base opens
           `ldr r1,[r0]; mov r4,r0`, writing r1 out of `this` before any read,
           and writes r2, r3 and ip before reading them too.
           dScMgD3DBase_c's override at ov006:0x020e6d24 writes
           `mov r1,#0x100; mov r2,r1` and reads neither on entry.
           dScMgSlot3_c's at ov006:0x0210aa3c settles it: it loads r2 and ip
           from its literal pool, CLOBBERS r1 with a masked read of the sub
           display-control register, and only then tail-branches `bx ip` into
           0x020af094.  A second argument passed in r1 would reach the base as
           a display-control word, so the base cannot be reading one.
           These are scene-family observations; agreement with an actor
           declaration at this index would not add independent evidence.
         overrides: SIX tables, TWO declarations, and NO reconciliation.  This
           is the first slot since 26 where no descendant had already declared
           the member early, so nothing has to be un-declared alongside it.
           dScMgD3DBase_c's own body at ov006:0x020e6d24 backs its table and
           all four of its children's; dScMgSlot3_c, which hangs off
           dScMgSingle3DBase_c rather than off D3DBase, has its own at
           ov006:0x0210aa3c.  dScMgSingle3DBase_c itself does not override.
         NAME CORRECTION, the sixth on dScMgD3DBase_c and the seventh in this
           campaign: 0x020e6d24 carried
           `recovered name: dScMgTrampoline2_c_SaveScreenForMenu`.  Five tables
           reference it, so it is dScMgD3DBase_c's.  Unlike slots 26, 27 and
           28 this one is not a twelve-byte veneer -- it is a real 0x68-byte
           body that loads a sub-screen OBJ palette and claims two VRAM banks
           before calling this class's, which is why it also had to change its
           include and the type it casts `this` to.
         SEMANTIC CAUTION, the first of its kind on this class.  Every method
           name here is transplanted from include/dActor_c.h at the same
           index.  Nothing in the cartridge carries a method name for
           dScMgBase_c -- its RTTI carries class names only -- so the
           `recovered name:` comments are themselves index transplants, not
           independent recoveries.  There was never a second witness, only the
           same witness reached twice.  Until now that cost nothing.  Here the
           ROM contradicts the transplant outright.  The sole ov004 dispatch
           site is guarded on an EDGE of mMenuOpen (+0x4628): OnGraphCallback2 compares
           mMenuOpen against mMenuScreenSaved and, only when they differ, calls slot 30
           if mMenuOpen is zero and THIS slot if it is not, then copies one
           into the other.  And this body does exactly what that guard implies.
           It saves POWCNT1's screen-swap bit and the two BG-enable bytes into
           mSavedScreenSwap, mSavedMainBgBits and mSavedSubBgBits; clears every
           layer- and window-enable bit in both DISPCNTs; saves 0x400 bytes of
           BG palette out of palette RAM into a buffer at +0x4228 and loads the
           menu's own palettes over it; and saves 0x2000 bytes of sub-screen
           OBJ VRAM at 0x06606000 into +0x2228 before decompressing a
           per-language image over that.  Save the screen, then draw over it:
           that is the three-item overlay menu going UP.  It is not a Yoshi
           egg.  The borrowed name was kept as a label at first; on
           2026-10-14 slots 18-35 were renamed from their bodies (see NAMES
           above).
         AND A WARNING FOR SLOT 30, measured here because it is cheaper to
           record now than to rediscover: include/dActor_c.h:151 declares slot
           30 returning a Vector3 BY VALUE.  That cannot be transplanted.  At
           ov004:0x020ae168 slot 30 is dispatched with r0 still holding `this`
           and r1 holding the loaded function pointer; a 12-byte return would
           put a hidden result pointer in r0 and `this` in r1 under AAPCS.
           Whatever slot 30 returns here, it is not a Vector3. */
    virtual int  SaveScreenForMenu();                   /* slot 29 */
    /* Slot 30 -- RestoreScreenFromMenu (formerly OnAimedAtWithEggReturnVec,
       dActor_c.h:151 at the same index). Both halves of the old name were
       MEASURED wrong here: it is slot 29's mirror, and it returns nothing.
         return type: void, and this is the one slot in the whole 18-35 range
           whose return type the BYTES settle rather than merely permit.  It
           was declared `int` here as a hint until the base body became a real
           member definition; that spelling is now refuted.
           ov004:0x020aeed8 sets no result on either exit -- the early one is a
           bare return after `cmp r0,#2` and the fall-through ends in a
           read-modify-write of DISPCNT.  Declaring the member `int` and
           letting control fall off the end costs no instruction, but it does
           reserve r0 as the result register, and the closing block wants four
           scratch registers.  mwcc then allocates r1-r4 where the ROM
           allocates r0-r3 -- fourteen of ninety-three words differ, with no
           other change to the source:
               ROM   ldr r0,[pc,#0x38] / mov r3,#0x4000000 / ldr r1,[r3]
               int   ldr r1,[pc,#0x38] / mov r4,#0x4000000 / ldr r2,[r4]
           Spelled `void` the function is byte-exact.  Contrast slots 31, 32,
           35 and the OnXxx slots, where `int` costs nothing because r0 is not
           contended at the exit -- there the hint stands unrefuted, which is
           NOT the same as confirmed.  decl_common.h:2321 and both overrides
           already said void.
           Neither dispatch site reads a result
           either, and that is measured, not assumed: dScMgBase_c::OnGraphCallback2
           (slot 24) is the only caller of this slot anywhere in ov004 or ov006
           -- see the whole-image `ldr rN,[rM,#0x78]` + `blx rN` scan under slot
           29 for the method -- and at ov004:0x020ae16c the very next
           instruction after the `blx`, reached through `b 0x020ae180`, is
           `add r0,r4,#0x4000`.  The result is dead one instruction later, on
           both arms of that branch.
         `ReturnVec` IS REFUTED, twice over.  include/dActor_c.h:151 declares
           slot 30 returning a Vector3 BY VALUE, and in THAT hierarchy that is
           itself a measurement (of 0x020100dc) -- so this is a genuine
           divergence between the two branches, not a defect in dActor_c.h.  In
           THIS one it cannot hold.  A 12-byte return is returned in memory
           under AAPCS: r0 would carry a hidden result pointer and `this` would
           move to r1.  At the dispatch, ov004:0x020ae168, r0 still holds
           `this` -- OnGraphCallback2's entry does `mov r4,r0` and never rewrites r0 --
           and r1 holds the loaded function pointer.  And the base's own body
           opens `ldr r1,[r0]`, reading its vptr out of r0.  Whatever this slot
           returns, it is not a Vector3, and it is not returned in memory.
           And the contrast is the whole lesson of this campaign in one pair
           of slots: over in dActor_c, 29 and 30 are a lock-on RADIUS and the
           AIM POINT derived from it, and 30 asks 29 virtually.  Here 29 and
           30 are a screen SAVE and the RESTORE that undoes it.  Same two
           indices, same shared ancestor, nothing else in common.  An index
           is not a name.
         arity: no explicit parameters, MEASURED THREE TIMES, the third
           destructively.  The base writes r1 out of `this` before reading it.
           dScMgD3DBase_c's override at ov006:0x020e6cac loads r1 from `this`
           for its first call and never reads an incoming one.
           dScMgSlot3_c's at ov006:0x0210aa10 CLOBBERS r1 with a masked read of
           the sub display-control register 0x0400000A before falling into
           0x020aeed8 -- a second argument passed in r1 would reach the base as
           a display-control word.
         overrides: SIX tables, TWO declarations, NO reconciliation -- the same
           shape as 29, and for the same reason: nothing in the family declared
           this member early.  dScMgD3DBase_c's body at ov006:0x020e6cac backs
           its own table and all four of its children's; dScMgSlot3_c, which
           hangs off dScMgSingle3DBase_c, has its own at ov006:0x0210aa10.
         NAME CORRECTION, the seventh on dScMgD3DBase_c and the eighth in this
           campaign: 0x020e6cac carried
           `recovered name: dScMgTrampoline2_c_RestoreScreenFromMenu` and
           included dScMgTrampoline2_c.h.  Five tables reference it, so it is
           dScMgD3DBase_c's.  Like 29's it is a real body, not a veneer, so the
           include and the type it casts `this` to had to change with the name.
         WHAT IT ACTUALLY DOES, and this is the finding that settles slot 29
           rather than merely cautioning about it: this body is the WORD-FOR-
           WORD MIRROR of 0x020af094.  Slot 29 saves POWCNT1's screen-swap bit
           into mSavedScreenSwap and the two BG-enable bytes into
           mSavedMainBgBits / mSavedSubBgBits, blanks both DISPCNTs, spools
           0x400 bytes of BG palette into the buffer at +0x4228 and 0x2000
           bytes of sub-screen OBJ VRAM at 0x06606000 into +0x2228, then draws
           the menu over the top.  This one restores every one of those, in
           reverse: POWCNT1 bit 15 from mSavedScreenSwap, both DISPCNT 0xe000
           fields, the palettes back out of +0x4228 (with +0x200 going to the
           sub screen), the 0x2000-byte VRAM block back to 0x06606000, and the
           two BG-enable bytes back out of mSavedMainBgBits / mSavedSubBgBits
           and into both DISPCNTs' 0x1f00 fields.  Save-then-draw at 29,
           restore at 30.  OnGraphCallback2 picks between them on an EDGE: it compares
           mMenuOpen (+0x4628) against mMenuScreenSaved (+0x462c), does nothing when
           they agree, calls THIS slot when mMenuOpen has fallen to zero and
           slot 29 when it has risen, then latches mMenuOpen into mMenuScreenSaved.
           mMenuScreenSaved is that edge latch and nothing else.  Slot 29 is the
           three-item overlay menu going up and slot 30 is it coming back down;
           neither has anything to do with a Yoshi egg or with a vector. */
    virtual void RestoreScreenFromMenu();          /* slot 30 */
    /* Slot 31 -- InitSubScreenBg (formerly Virtual7C, and before that the
       borrowed `Kill`). This is the first slot above dActor_c's table, and
       reaching it settled what the thirteen slots below it only hinted at.
         WHY THE NAME CHANGES HERE.  Slots 18-30 carry dActor_c's names because
           they sit at dActor_c's indices.  That is the whole of the argument,
           and at this slot it runs out: include/dActor_c.h stops at 30.  What
           the two tables actually share is their BASE, not their tail --
           include/fBase_c.h declares slots 0-15 plus the destructor pair at
           16/17, and dBase_c adds no virtual of its own, so both branches begin
           appending at 18:
               fBase_c -> dBase_c -> dActor_c                  (adds 18-30)
               fBase_c -> dBase_c -> dScene_c -> dScMgBase_c   (adds 18-35)
           dScMgBase_c is a SCENE, not an actor; dScene_c and dActor_c are
           siblings under dBase_c and dScene_c declares nothing above slot 11.
           Two independent extensions of the same 18-slot base land on the same
           indices for the same reason two books have a page 19.  That is the
           root cause behind every semantic contradiction recorded at slots 26,
           29 and 30, and it applies to all eighteen.
         WHERE `Kill` CAME FROM, since the sources still say it.  ov002 really
           does carry _ZN10dBgActor_c4KillEv at 0x020ee55c -- a genuine mangled
           ROM symbol, and notes/actor-vtables.md derives it independently.  But
           dBgActor_c derives from dActor_c: it is a NEPHEW of this branch, and
           Kill is the one new virtual IT appends at ITS slot 31.  The name was
           carried across a fork, not down a chain.  Nothing in the cartridge
           names this function.  It took the offset spelling Virtual7C first;
           InitSubScreenBg is coined from what the body does.
         return type: int, A HINT, the third consecutive slot no body pins.
           ov004:0x020b2880 sets r0 to #0 on its second instruction -- as
           SetSubBg1Offset's first argument, before anything reads it -- and
           never assigns a result; whatever falls out is LoadCompressedFileAt's
           return.  The one caller discards it (below).
         arity: no explicit parameters, MEASURED at the only in-family call
           site.  Scanning arm9 and all 103 overlays for `ldr rN,[rM,#0x7c]`
           immediately followed by `blx rN` -- the dispatch pair, not any load
           at +0x7c -- finds 39 sites, of which exactly ONE is in ov004 or
           ov006: ov004:0x020b0a0c, inside dScMgBase_c::BeforeInitResources.
           It reads `mov r0,r4; ldr r1,[r0]; ldr r1,[r1,#0x7c]; blx r1`, so r1
           is the loaded pointer and cannot also be a second argument.  The
           other thirty-eight sites are in ov002, ov015, ov018, ov027, ov064,
           ov079, ov081 and ov098 -- dBgActor_c's Kill, on the other branch.
           The base body does not even read `this`; dScMgD3DBase_c's override
           does (unk_4660, mSubBgBank), which is what fixes r0 as the object.
         WHAT IT DOES.  All four bodies are one shape.  Three read-modify-writes
           on the sub engine's BG1CNT at 0x0400100a (`& 0x43`, `| X`, `& ~0x40`,
           `& ~3`) leave the register holding exactly X: priority 0, no mosaic,
           and the class's own base-block bits -- 0x10 here, 0x800 in
           dScMgD3DBase_c, 4 in both dScMgAmida_c and dScMgSmartball_c.  Then
           SetSubBg1Offset(0, 0) resets the layer's scroll, `data_0209d454 &= ~2`
           clears BG1's bit in the sub BG-enable shadow that slot 30 restores
           the sub DISPCNT from, and two LoadCompressedFileAt calls install a
           language-indexed character file at G2S::GetBG1CharPtr() and the
           shared screen map, file 0x5b, at G2S::GetBG1ScrPtr().  Each class
           differs only in X and in its own language table.  It installs this
           minigame's touch-screen background; it destroys nothing.
         WHEN IT RUNS.  BeforeInitResources (ov004:0x020b0930) calls slot 33 at
           +0x84, zeroes data_0209d460 and data_0209d458 -- the main/sub pair
           slot 30 restores the DISPCNT layer bits from -- calls THIS slot last,
           and returns a literal 1 without touching the result.  Setup, at scene
           construction.
         overrides: SEVEN tables, THREE declarations, no reconciliation.
           dScMgD3DBase_c's body at ov006:0x020e72c0 backs its table and all
           four children's; dScMgAmida_c (ov006:0x020d11a0) and
           dScMgSmartball_c (ov006:0x02118ae4) each have their own.
         NAME CORRECTION, the ninth in this campaign and the eighth on
           dScMgD3DBase_c: 0x020e72c0 carried
           `recovered name: dScMgTrampoline2_c_Kill` and included
           dScMgTrampoline2_c.h.  Five tables reference that address, so it is
           dScMgD3DBase_c's.  Fixed here along with the type it casts `this` to. */
    virtual int  InitSubScreenBg();                          /* slot 31 */
    /* Slot 32 -- InitMainScreenBg (formerly Virtual80, and before that the
       borrowed `AfterClsn`), and it is slot 31 again with the other display
       engine.  Reading the two bodies side by side is the fastest way to see
       that neither name the recovery pass gave them was ever a measurement.
         WHY THE NAME CHANGES, and it is a WORSE case than 31.  `AfterClsn` is a
           genuine ROM name -- include/PathLift.h:58 declares it and
           _ZN16dPathLiftActor_c9AfterClsnEi is a real mangled symbol -- but
           dPathLiftActor_c derives from dBgActor_c, which derives from
           dActor_c.  That is TWO forks off this branch, not one:
               fBase_c -> dBase_c -> dActor_c -> dBgActor_c -> dPathLiftActor_c
               fBase_c -> dBase_c -> dScene_c -> dScMgBase_c
           The shared ancestry stops at dBase_c, which adds no virtual, so the
           only thing the two indices have in common is fBase_c's 18-slot base.
           dPathLiftActor_c's AfterClsn also takes an `int`; this slot takes
           nothing.  Same borrowed-label defect settled at slot 31, one fork
           further out.  InitMainScreenBg is the offset spelling, as at 31 and as
           slots 33-35 are recorded in notes/dScMgBase_c-slots-18-35.md.
         WHAT IT DOES -- the MAIN screen, where 31 did the sub.  Line for line
           the same body against the other engine: three read-modify-writes on
           the MAIN BG1CNT at 0x0400000a (`& ~3`, `(& 0x43) | 0x1000`, `& ~0x40`)
           leave it holding exactly 0x1000, SetBg1Offset(0, 0) resets the
           layer's scroll, `data_0209d45c &= ~2` clears BG1's bit in the MAIN
           BG-enable shadow that slot 30 restores the main DISPCNT from, and two
           LoadCompressedFileAt calls install a language-indexed character file
           and the shared screen map -- file 0x67 here, 0x5b there.  Slot 31
           went through G2S::GetBG1CharPtr and G2S::GetBG1ScrPtr; this one goes
           through func_02054ea8 and _ZN2G212GetBG1ScrPtrEv (ov004:0x020b2848
           and 0x020b285c).  So the ROM itself names the pair G2S/G2.  It builds
           this minigame's TOP-screen background; it has nothing to do with
           collision.
         WHEN IT RUNS, and this is the other half of the symmetry.  Slot 31 is
           called last by dScMgBase_c::BeforeInitResources; slot 32 is called
           FIRST by dScMgBase_c::AfterInitResources(u32) at ov004:0x020b0900,
           before the scene goes live.  Before/after, sub/main.
         arity: no explicit parameters, MEASURED at that one call site.  The
           whole-image scan for the dispatch pair at +0x80 (`ldr rN,[rM,#0x80]`
           with Rn != pc, followed within three instructions by `blx rN`) finds
           exactly THREE sites: ov004:0x020b0900, and ov002:0x020effa4 plus
           ov064:0x02116e58, which are dPathLiftActor_c::AfterClsn on the other
           branch.  At the ov004 site the sequence is
           `ldr r2,[r0]; mov r5,r0; ldr r2,[r2,#0x80]; mov r4,r1; blx r2` --
           r0 is `this`, and r1 is AfterInitResources's own `vfSuccess`, saved
           into r4 BECAUSE the call clobbers it and handed to
           0x0203188c afterwards.  A callee that consumed r1 would not need it
           parked first.
         return type: void, MEASURED -- and it corrects the `int` this block
           used to carry, which it called "A HINT ... no body pins".  A body
           pins it now.  dScMgSlot3_c's override was converted to a real member
           definition, and as `int` mwcc reserves r0 for the result: its closing
           read-modify-write on BG1CNT then allocates r1-r3 where the ROM
           allocates r0-r2, six of forty-two words differing with no other
           source change.

               ROM   ldr r2,[pc,#0x18] / ldr r0,[pc,#0x20] / ldrh r1,[r2]
               int   ldr r3,[pc,#0x18] / ldr r1,[pc,#0x20] / ldrh r2,[r3]

           Spelled void both bodies are byte-exact.  The base's own body was
           byte-exact either way -- its last statement is the
           LoadCompressedFileAt call, so r0 is already the call's result and
           nothing contends for it -- which is exactly why the hint survived
           unrefuted for so long.  Unrefuted is not confirmed.  The return type
           is not part of the Itanium mangled name, so nothing moved: no
           symbol, no vtable, no config entry.  Same adjudication as slot 30.
         overrides: ONE table, one declaration -- dScMgSlot3_c
           (ov006:0x0210aa60), which repeats the base body verbatim and then
           writes BG1CNT once more, to 0x1118 instead of the base's 0x1000:
           same layer, this minigame's own character and screen base blocks.
           No reconciliation, no misattribution: the smallest slot in the
           campaign after 22's zero. */
    virtual void InitMainScreenBg();                          /* slot 32 */
    /* Slot 33 -- InitEngines (formerly Virtual84), the display bring-up.
         WHY THE NAME.  Neither override body carries a `recovered name:` line
           and neither does the base, so unlike slots 26, 29, 30, 31 and 32 there
           is no borrowed dActor_c label here to retire -- there was never one to
           borrow, because dActor_c's table ends at slot 30 and dScMgBase_c is on
           the sibling branch anyway (fBase_c -> dBase_c -> dScene_c ->
           dScMgBase_c; see the slot-31 block above).  Nothing in the cartridge
           names this method -- RTTI carries class names only -- so it first took
           the offset spelling Virtual84; InitEngines is coined from the body.
         return type: void, and here that is the reading of the bodies rather
           than a default.  All three fall off the end without setting a result,
           the one call site discards whatever is in r0, and -- unlike slots
           28-32 -- one of the three is about to become a real member definition
           (see below), where a declared `int` with no return statement would be
           a lie the compiler has to paper over.  notes/dScMgBase_c-slots-18-35.md
           records the signature as void(char *obj) and this agrees with it.
         arity: no explicit parameters, MEASURED.  Scanning arm9 and all 103
           overlays for the dispatch pair -- `ldr rD,[rN,#0x84]` with rN != 15,
           followed within three instructions by `blx rD` -- finds TWO sites in
           the whole image, of which exactly one is in ov004 or ov006:
           ov004:0x020b09d0, inside dScMgBase_c::BeforeInitResources.  It reads
           `mov r0,r4; ldr r1,[r0]; ldr r1,[r1,#0x84]; blx r1`, so r1 holds the
           loaded pointer and cannot also be a second argument, and r0 is `this`.
           The scan was validated against a known answer first: the same run at
           +0x80 reproduces slot 32's site (ov004:0x020b0900) and nothing else in
           the family.  The other +0x84 hit is in ov064, outside this hierarchy.
         `this` IS carried, and for once the base body proves it on its own.
           Slots 26-32 all had base bodies that never touched the object; this
           one writes obj[0x68] and obj[0x6c] on its second and third statements
           and then publishes obj itself into the scene registry.
         WHAT IT DOES.  This is the engine bring-up, and it runs BEFORE anything
           else the family does.  Both engines get a graphics mode, VRAM banks
           are assigned, both BG-enable shadows are initialised to 0x10 --
           data_0209d45c for main and data_0209d454 for sub, the same pair slot
           30 restores the DISPCNTs from and slots 31 and 32 clear BG1 out of --
           a language-indexed compressed character file is decompressed into BG
           character VRAM, OBJ palette file 0xc3 is loaded into both engines, and
           the scene object is published into the global registry at
           sMgGraphCallback[1] / data_0209d4a8.  The three bodies differ
           exactly where the classes differ: the base is 2D (GX mode (1,0,0),
           GXS mode 0, BG bank 3), dScMgD3DBase_c is 3D (DisableAllBanks first,
           texture and texture-palette banks, GX mode (1,0,1), GXS mode 5, BG
           bank 2, InitialiseVramGlobals, and it keeps the decompressed file
           pointers in globals), and dScMgSingle3DBase_c is the base's 2D
           sequence with the 3D banks folded in.
         WHEN IT RUNS.  BeforeInitResources (ov004:0x020b0930) dispatches this
           slot at 0x020b09d0, near the top, and dispatches slot 31 at
           0x020b0a0c, last.  With slot 32 called first out of
           AfterInitResources, the whole sequence reads: bring the engines up
           (33), dress the sub screen (31), then dress the main screen (32).
         overrides: NINETEEN tables, TWO declarations -- structurally slot 26
           over again, and the same two classes own the bodies.  Thirteen
           children of dScMgSingle3DBase_c and four of dScMgD3DBase_c point at an
           ancestor's body and declare nothing; declaring the slot on any of
           those seventeen would invent an override the cartridge does not have.
         FIRST OVERRIDE INSIDE A PROMOTED TU.  dScMgSingle3DBase_c's body is not
           a one-function file -- it lives inside the intact-object unit
           src/actors/dScMgSingle3DBase_c.cpp (promoted in #2064), where it has
           been waiting on this declaration by name since then: the slot-26
           member in that file ends "Slot 33 below is still waiting on the same
           declaration."  It was the last vtable slot in that unit still spelled
           as a mangled free function (0x0210a534, the only other one left, is in
           no vtable at all), so this turns it into a real member definition and
           takes the class from a byte-exact 33-slot vtable prefix to 34. */
    virtual void InitEngines();                          /* slot 33 */
    /* Slot 34 -- PaintSquare, the first slot in this family that takes arguments,
       and the first whose job is legible from the body without any naming help.
       IT IS THE BRUSH.  ov004:0x020ae3b4 walks a size x size square centred on
         (cx, cy), and for each cell inside it computes the address of one
         4-bit pixel in BG character VRAM -- `(x/8 + (y/8)*32)*32 + (y&7)*4`,
         the standard DS 4bpp char layout -- reads the containing word, splices
         `colour` into the nibble at `(x&7)*4`, and writes it back.  Sixteen
         colours, one palette index per pixel.  It clips on all four sides.
       THE TWO FIELDS SLOT 33 INITIALISES ARE THE ONES IT READS.  Slot 33
         (InitEngines, engine bring-up) sets `obj+0x68` to 0 and `obj+0x6c` to -1.
         Here `obj+0x6c` selects WHICH background layer to draw into -- 0..3
         index G2S::GetBG0CharPtr through GetBG3CharPtr, anything else returns
         without drawing, which is what -1 buys -- and `obj+0x68` gates the
         wrapped region above the touch screen, where the main engine's
         G2::GetBG*CharPtr are used instead and y is folded by
         `+ sMgTopScreenYOffset + 0xc0`.  So slot 33 leaves the brush disabled
         and a minigame arms it by picking a layer.  Two slots, one mechanism.
       WHO CALLS IT: ov004:0x020ae5c4, a line rasteriser sitting immediately
         after the brush in the image, which dispatches through +0x88 at seven
         separate sites as it steps along a segment.  That is the whole of the
         in-family call graph for this slot -- every one of the seven is inside
         that one function.  A line-drawing minigame is exactly the set that
         overrides it (dScMgAmida_c is the ghost-leg/stylus one).
       arity: FOUR explicit parameters, MEASURED and unanimous.  Every one of
         the seven sites sets up r1, r2, r3 AND one stack word before the call
         -- e.g. at 0x020ae690, `mov r1,sb; mov r2,r8` with r3 loaded from
         [sp,#0x3c] and [sp] already holding r7 -- so the callee takes this plus
         four.  Image-wide the +0x88 dispatch pair appears 14 times, 7 in
         ov004/ov006 and 7 in ov064; the scanner is the one validated at slot 33
         by reproducing slot 32's site at +0x80.
       return type: void, and here the ROM says so rather than merely permitting
         it.  Two of the seven sites (0x020ae7e4, 0x020ae83c) overwrite r0 on
         the very next instruction with `ldr r0,[sp,#0xc]`; the rest tail-return
         without reading it.  All five bodies fall off the end without setting a
         result.
       NOTHING TO CORRECT, as at slot 33: no `recovered name:` line exists on
         the base body or on any of the four overrides, so no borrowed label is
         being retired.  PaintSquare (formerly Virtual88) is coined from the
         body: it paints a size x size square of one palette index.
       overrides: FOUR tables, FOUR declarations, nothing inherited and nothing
         shared -- dScMgAmida_c (ov006:0x020d14c0), dScMgTeresa_c (0x021200dc),
         dScMgTrampoline_c (0x02120da8) and dScMgTrampoline2_c (0x02122cb0) each
         have a body of their own.  dScMgD3DBase_c does NOT override this slot,
         so its two trampoline children declare it themselves rather than
         inheriting a shared body the way they do at 26-31 and 33.
       dScMgAmida_c's body decompiles with only THREE explicit parameters.  That
         is not a contradiction: the fourth arrives on the stack and that body
         never reads it, so the reconstruction had nothing to name.  The slot's
         signature is fixed by the call sites, which are unanimous, and an
         ignored stack argument costs the callee nothing. */
    virtual void PaintSquare(int cx, int cy, int colour, int size); /* slot 34 */
    /* Slot 35 -- IsAltVariant, the LAST slot of dScMgBase_c's own eighteen and the
       end of the 18-35 range.  With this declared the class emits its full
       36-slot vtable from source, and dScMgAmida_c's Unk36 finally lands on 36
       where the ROM puts it.
       WHAT IT IS: a predicate on the scene's own spawn parameter.  The base
         body (ov004:0x020ad660, twenty bytes) is `return (param1 & 0xff) != 0`
         -- fBase_c::param1 at +0x08, the word every fBase_c is constructed
         with.  dScMgAmida_c's override (ov006:0x020d1170, twenty-four bytes)
         asks the narrower question, `== 1`.  Nothing else in the family
         overrides it, so thirty-one of the thirty-two tables carry the base's
         answer.
       WHO CALLS IT, and this is the strongest call-site evidence in the whole
         campaign: THIRTEEN dispatch sites, spread across FOUR different leaf
         classes' code regions -- dScMgCoin_c (2), dScMgPanel_c (4),
         dScMgSound_c (3) and dScMgSnowball_c (4).  Each is the same shape,
         `mov r0,<this>; ldr r1,[r0]; ldr r1,[r1,#0x8c]; blx r1`, a class asking
         the question of ITSELF.  They use the answer to pick between two
         variants of the same minigame: two asset tables at ov006:0x02105488,
         a different field path at 0x0211b9e0, a whole block skipped at
         0x02126f58.
       arity: no explicit parameters, MEASURED.  r1 is the loaded function
         pointer at every one of the thirteen sites and so cannot also be an
         argument, and r2/r3 are never set up for the call.  `this` only.
       return type: int, and this is the first slot in the campaign where the
         ROM does not merely permit a return value but is SEEN TO CONSUME ONE.
         All 13 sites follow the call with `cmp r0, #0` and branch on the
         result.  Both bodies compute a comparison and return it, so the value
         is 0 or 1; `int` is the spelling slots 29-32 already use for the same
         shape.
       NOTHING TO CORRECT, as at slots 33 and 34: no `recovered name:` line on
         the base body or on the one override.  IsAltVariant (formerly
         Virtual8C) is coined from its callers: it says the scene runs the
         second variant of a menu row (param1's low byte).
       the rename is SCOPED.  0x020ad660 is an overlay load base, so ov000,
         ov002, ov003, ov004 and ov007 each have a different, unrelated symbol
         at that address -- ov003's was dScTitle_c's D1.  Only
         func_ov004_020ad660 was this one, so the rename was keyed on that
         module-qualified symbol; keying it on the address would have hit
         five files in four unrelated overlays and every byte gate would
         still have passed. */
    virtual int  IsAltVariant();                          /* slot 35 */

    /* THAT IS ALL EIGHTEEN.  Slots 18-35 are declared, each in its own
       commit together with every descendant override of that slot, and this
       class emits its full 36-slot vtable from source.  Nothing in the family
       is a prefix any more.

       Slots 18-30 used to carry names borrowed from dActor_c by INDEX, which
       was a coincidence and not evidence: dScMgBase_c is a scene
       (fBase_c -> dBase_c -> dScene_c -> dScMgBase_c), a sibling branch that
       happens to start appending its own virtuals at the same index dActor_c
       does.  They were retired on 2026-10-14 (see NAMES at the top of this
       range).

       THE OCCUPIED-SLOT TRAP IS NO LONGER LOADED IN dScMgSlot1_c -- slots 27
       and 28 were both of its early declarations and both are reconciled --
       but it is a property of the FAMILY, not of that one class.  Before
       adding any FURTHER virtual to this class, check every descendant
       header for a virtual that already lands on the new index by
       arithmetic.  Declaring the base's while a
       descendant keeps a different signature makes them two different
       functions, pushes the descendant's own down one index, and regresses its
       table to DIFFERS with rombuild still green -- only romdata_check sees
       it.  Reconcile in the same commit, and remember the rename has to reach
       config/converted-baseline.json (the ratchet has no rename detection) and
       any prose path that names the file. */

    s32 mTallyShown;            /* 0x050 */
    s32 mTallyAnimTimer;            /* 0x054 */
    s32 mTimeLimit;         /* 0x058 -- 60 or 120 from the scene ID */
    s32 mFrameCounter;      /* 0x05c -- wraps every 40 frames */
    s32 mRecordRevealTimer;            /* 0x060 */
    s32 mLastRecordRank;            /* 0x064 */
    u8  pad_068[0x38];
    s32 mSubBgBank;            /* 0x0a0 */
    s32 mRunDuringFade;            /* 0x0a4 */
    s32 mCredits;            /* 0x0a8 */
    s32 mCreditsShown;            /* 0x0ac */
    u8  pad_0b0[0x4];
    s32 mHudScore;          /* 0x0b4 -- zeroed by BeforeInitResources. Leaves
                                count into it or copy their own tally here, and
                                the value leaves submit through
                                Mg_SubmitScore, which stores it at
                                mSubmittedScore */
    s32 mBestHudScore;            /* 0x0b8 */
    u32 mLevel;            /* 0x0bc */
    u16 mPromptBlinkTimer;  /* 0x0c0 -- free-runs 0..0x2f; the prompt shows
                                during the first 0x18 frames of each cycle */
    u8  unk_0c2;            /* 0x0c2 -- constructor seeds this to 1 */
    u8  mPromptEnabled;     /* 0x0c3 -- nothing is drawn while this is 0 */
    u8  mPromptBlinkCount;  /* 0x0c4 -- after 4 blink cycles the per-language
                                prompt sprite stays up every frame */
    u8  pad_0c5[0x3];
    s32 mMusicTrack;            /* 0x0c8 */
    dMgState_c mStateController; /* 0x0cc -- minigame UI state controller */
    dMgPsOpt_c mTouchOptions; /* 0x0f4 -- eight polymorphic touch icons */
    u32 mSavedMainBgBits;   /* 0x21c -- SaveScreenForMenu saves data_0209d45c
                                here and RestoreScreenFromMenu restores it */
    u32 mSavedSubBgBits;    /* 0x220 -- the same pair for data_0209d454 */
    u32 mSavedScreenSwap;   /* 0x224 -- bit 15 of POWCNT1 (0x4000304), saved and
                                restored by the same two functions */
    u8  pad_228[0x4400];
    s32 mMenuOpen;          /* 0x4628 -- the three-item overlay menu is up;
                                BeforeRender skips the normal render pass and
                                draws that instead */
    s32 mMenuScreenSaved;           /* 0x462c */
    s32 mMenuDisabled;           /* 0x4630 */
    s16 mMenuItem0X;        /* 0x4634 */
    s16 mMenuItem0Y;        /* 0x4636 */
    s16 mMenuItem1X;        /* 0x4638 */
    s16 mMenuItem1Y;        /* 0x463a */
    s16 mMenuItem2X;        /* 0x463c */
    s16 mMenuItem2Y;        /* 0x463e */
    s32 mMenuCursorPhase;   /* 0x4640 -- drives the highlighted item's pulse */
    u8  pad_4644[0x2];
    s16 mMenuCursor;        /* 0x4646 -- highlighted item, -1 for none */
    s32 mQuitFadeStarted;           /* 0x4648 */
    s32 mSubmittedScore;           /* 0x464c */
    s32 mTopRecord;         /* 0x4650 -- saved best, seeded from the save table */
    s32 mSessionBest;           /* 0x4654 */
    s32 mRankedScore;           /* 0x4658 */
    u8  mNewRecord;           /* 0x465c */
    u8  pad_465d[0x1];
    s16 mSceneKind;         /* 0x465e -- table-selected from param1's high byte */
};

/* The nested callback class the ROM's type graph records for this scene,
   deriving from dGraph_c::callback_c (include/dGraph_c.h). It is registered
   with the owning scene as its context; mScene at +0x4 is that back-pointer,
   read by all four slots. Declaring the class adds no storage to
   dScMgBase_c -- the object itself is not a member of this class.

   The slots are declared virtual, matching dGraph_c::callback_c's own
   declarations (include/dGraph_c.h): the base supplies the vptr at +0x0,
   so the derived fields fall where the ROM puts them, and strict object
   isolation discards the vtable/RTTI passengers the function range does
   not own. */
class dScMgBase_c::graphCallback_c : public dGraph_c::callback_c {
public:
    dScMgBase_c *mScene;                             /* 0x04 */

    graphCallback_c();

    virtual int GraphCallback0();                            /* slot 0 */
    virtual int GraphCallback1();                            /* slot 1 */
    virtual int GraphCallback2();                            /* slot 2 */
    virtual int GraphCallback3();                            /* slot 3 */
};

/* The modeled storage spans 0x4660. The constructor initializes the
   halfword mSceneKind at 0x465e; 0x465c is not the last observed field.
   See notes/minigame-provenance.md for the earlier layout evidence. */
#ifndef SM64DS_PLATFORM_PC
/* ROM layout under mwccarm; host ABI divergence is tracked separately. */
typedef char dScMgBase_c_size_must_be_0x4660[sizeof(dScMgBase_c) == 0x4660 ? 1 : -1];
#endif

#endif
