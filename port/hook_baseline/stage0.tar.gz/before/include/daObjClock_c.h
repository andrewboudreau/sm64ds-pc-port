#ifndef DAOBJCLOCK_C_H
#define DAOBJCLOCK_C_H

#include "types.h"
#include "dActor_c.h"
#include "Model.h"

/* daObjClock_c -- the two rotating hands of the clock painting.
 *
 * THE NAME COMES OUT OF THE CARTRIDGE. The vtable header at ov013 0x021121f8
 * is {0, 0x021121a4}; that _ZTI is the three-word __si_class_type_info record
 * {0x0209a764, 0x021121b0, 0x0208e390} -- first word __si_class_type_info's
 * vtable+8, second the length-prefixed string "12daObjClock_c" at 0x021121b0,
 * third _ZTI8dActor_c in config/arm9/symbols.txt. So the ROM states the name
 * and the `: dActor_c` base. The file was ClockPaintingHandShort.h until that
 * read renamed it; _ZTV22ClockPaintingHandShort was a coined alias sitting on
 * the same 0x02112200 address point and is gone from symbols.txt.
 *
 * ONE CLASS, TWO PROFILES. CLOCK_SHORT (actor 292) and CLOCK_LONG (actor 293)
 * each own a descriptor and a separate factory, and both install this
 * one vtable and the same 0x128 allocation. InitResources tells them apart at
 * run time by actorID and stores the answer in mHandIndex.
 *
 * LAYOUT: dActor_c occupies 0x000..0x0cf; four bytes of derived padding precede
 * the owned Model the implicit constructor builds at +0xd4 (_ZN5ModelC1Ev);
 * the one-byte hand index follows it at 0x124. The helper at 0x02111430 writes
 * mModel.mat4x3 from mAngleX/Y/Z and mModel.mat4x3.t from mPosX/Y/Z >> 3.
 */

#ifdef __cplusplus

extern "C" void *_ZN7fBase_cnwEj(unsigned size);

struct daObjClock_c : dActor_c {
    u8    pad_0d0[0x4];    /* 0x0d0 */
    Model mModel;          /* 0x0d4 */
    u8    mHandIndex;      /* 0x124 -- 0 = long hand, 1 = short hand */
    u8    pad_125[0x3];    /* 0x125 */

    /* --- vtable. The destructor is INLINE, and that is load-bearing rather
       than a style choice. Out of line, mwccarm emits D0 before D1 -- the
       reverse of the ROM's 0x021113bc D1 / 0x021113ec D0 order, which makes
       objisolate refuse the whole TU -- and additionally emits a D2 that has
       no home anywhere in the cartridge. Inline, it emits exactly the retail
       D1/D0 pair in ROM order and no D2. Nothing derives from this class, so
       no descendant needs to `bl` a D2.

       Declared FIRST, deliberately: with the destructor inline the key
       function is the first DECLARED non-inline virtual, so this ordering is
       what makes src/game/actors/d_a_obj_clock.cpp the TU that emits the
       _ZTV/_ZTI/_ZTS group -- exactly what the promotion needs it to be. --- */
    virtual ~daObjClock_c() {}         /* slots 16 (D1), 17 (D0) */

    /* --- overrides of inherited fBase_c slots dActor_c left untouched.
       The ROM installs all four in the vtable at 0x02112200. Matching an
       inherited virtual signature already makes an override virtual without
       repeating the keyword. These explicit declarations document that role;
       the inline destructor and declaration order above control TU emission. --- */
    virtual int InitResources();       /* slot 0 -- 0x021115cc */
    virtual int CleanupResources();    /* slot 3 -- 0x02111478 */
    virtual int Behavior();            /* slot 6 -- 0x021114cc */
    virtual int Render();              /* slot 9 -- 0x021114a4 */

    /* State helper taking this (S33): the ROM address is the method name. */
    void func_ov013_02111430();

    /* Until #2570 merges, a leaf `unsigned long` new forwards the retail
       `fBase_c::operator new(unsigned int)`. `unsigned int` here mangles
       differently and the factories miss. */
    static void *operator new(size_t size) {
        return _ZN7fBase_cnwEj((unsigned)size);
    }
};

/* Holds the chain to the size both factories' operator new(0x128) evidences.
   A silently-added member anywhere fails this. */
#ifndef SM64DS_PLATFORM_PC
/* ROM layout under mwccarm; host ABI divergence is tracked separately. */
typedef char daObjClock_c_size_must_be_0x128[sizeof(daObjClock_c) == 0x128 ? 1 : -1];
#endif

#endif /* __cplusplus */

#endif /* DAOBJCLOCK_C_H */
