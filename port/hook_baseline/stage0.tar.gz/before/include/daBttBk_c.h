#ifndef DABTTBK_C_H
#define DABTTBK_C_H
#include "types.h"
#include "dActor_c.h"
#include "Model.h"
#include "dExtShadowModel_c.h"
#include "dCcAc_c.h"
#include "dBgCh_Actr.h"

/* TWO WITNESSES:
 *
 *   daBttBk_c_classInit  fBase_c::operator new(888 = 0x378),
 *       dActor_c::dActor_c(), stores _ZTV9daBttBk_c, then the four
 *       members below in this order.
 *   _ZN9daBttBk_cD0Ev  the same four members destroyed in reverse,
 *       then ~dActor_c.
 *
 * SIZE 0x378 is the factory's own literal; mCarrier (4 bytes, 0x374) closes
 * exactly on it.
 *
 * Everything below 0x0d0 duplicated dActor_c's own fields under placeholder
 * names -- dActor_c ends at exactly 0x0d0. Two consumer fields were
 * repointed to inherited dActor_c names: unk_09c -> mVertAccel, unk_0a0 ->
 * mTerminalVelocity, unk_0b0 -> mFlags (mPosX/Y/Z and mScaleX/Y/Z already
 * shared dActor_c's names).
 *
 * mWithMeshClsn was mistyped `u8` at 0x180 in the generated header --
 * daBttBk_c_classInit calls _ZN10dBgCh_ActrC1Ev at that offset, so it is the
 * real 0x1bc-byte member (0x180..0x33c). The 0x38 bytes from 0x33c..0x374
 * are named from how d_a_btt_bk.cpp uses them: a shadow matrix at 0x33c
 * (func_ov080_02124c3c), the current state-table row at 0x36c and its index
 * at 0x370; mCarrier holds the carrier actor (func_ov080_02124acc stores it,
 * 02124c3c/02124edc read it).
 *
 * THE VTABLE was diffed slot by slot against _ZTV8dActor_c. daBttBk_c
 * overrides slot 0 (InitResources), slot 3 (CleanupResources), slot 6
 * (Behavior) and slot 9 (Render) -- all still fBase_c's own slots in
 * dActor_c -- plus slot 12 (OnPendingDestroy, an extern "C" empty-body free
 * function), 18 (OnYoshiTryEat) and 19 (OnTurnIntoEgg). Every other slot
 * holds the base's own word and is inherited, so it is deliberately not
 * redeclared here.
 *
 * SM64DS RTTI names the implementation daBttBk_c. The reconstructed
 * factory daBttBk_c_classInit (historical alias
 * CrazedCrate_Spawn) constructs it for the BATTA_BLOCK
 * registry profile.
 */
struct daBttBk_c : dActor_c {
    u8  pad_0d0[0x4];
    /* Model member, named by the class's own destructor calling
       Model's D1 at +0x0d4. [daBttBk_c D0, src/game/actors/d_a_btt_bk.cpp] */
    Model mModel;            /* 0x0d4 */
    /* dExtShadowModel_c member, named by the class's own destructor calling
       dExtShadowModel_c's D1 at +0x124. [daBttBk_c D0, src/game/actors/d_a_btt_bk.cpp] */
    dExtShadowModel_c mShadowModel;            /* 0x124 */
    /* dCcAc_c member, named by the class's own destructor calling
       dCcAc_c's D1 at +0x14c. [daBttBk_c D0, src/game/actors/d_a_btt_bk.cpp] */
    dCcAc_c mdCcAc_c;            /* 0x14c */
    /* dBgCh_Actr member, named by daBttBk_c_classInit's own C1 call and the
       class's own destructor's D1 call at +0x180.
       [daBttBk_c_classInit and D0, src/game/actors/d_a_btt_bk.cpp] */
    dBgCh_Actr mWithMeshClsn;            /* 0x180 */
    u8  mShadowMtx[0x30];   /* 0x33c -- Matrix4x3 for the drop shadow (func_ov080_02124c3c) */
    char *mStateRow;        /* 0x36c -- current row of the state table */
    s32 mState;             /* 0x370 -- index stored by each state's enter function */
    dActor_c *mCarrier;     /* 0x374 -- the actor this crate rides, or null */

    virtual ~daBttBk_c();            /* slots 16 (D1), 17 (D0) */

    virtual s32  InitResources();         /* slot  0 */
    virtual s32  CleanupResources();      /* slot  3 */
    virtual s32  Behavior();         /* slot  6 */
    virtual s32  Render();           /* slot  9 */
    virtual void OnPendingDestroy();      /* slot 12 */
    virtual s32  OnYoshiTryEat();         /* slot 18 */
    virtual void OnTurnIntoEgg(Player &player); /* slot 19 */

    /* Non-virtual. The first parameter was this actor, so each is a member.
       The cartridge keeps no English spelling; the ROM address is the name. */
    void func_ov080_02124acc();
    void func_ov080_02124c3c();
    int func_ov080_02124e60();
    int func_ov080_02124eb0();
    int func_ov080_02124edc();
    int func_ov080_02124fec();
    int func_ov080_0212500c();
    int func_ov080_0212509c();
    void func_ov080_021250c8();
    void func_ov080_02125104();
    void func_ov080_0212513c(int i);
};

#ifndef SM64DS_PLATFORM_PC
/* ROM layout under mwccarm; host ABI divergence is tracked separately. */
typedef char daBttBk_c_size_must_be_0x378[sizeof(daBttBk_c) == 0x378 ? 1 : -1];
#endif

#endif
