#ifndef DAKPFR_C_H
#define DAKPFR_C_H

#include "dCcAc_c.h"
#include "dExtShadowModel_c.h"
#include "dBgCh_Actr.h"
#include "dActor_c.h"

extern "C" void *_ZN7fBase_cnwEj(unsigned size);

/* daKpFr_c is the ROM's own RTTI name for this class (this tree once coined it
 * FlameChompFire): the typeinfo at ov070
 * 0x02123418 names dActor_c as the sole base at offset 0, and the class's
 * vtable at 0x02123448 (31 slots, same count as dActor_c's) is what pairs it
 * to daKpFr_c_classInit (historical aliases daKpFr_c_Spawn and
 * FlameChompFire_Spawn).
 * The factory is `return new daKpFr_c()`. A bare `new` without the leaf
 * operator new below relocates to unresolved `_Znwm`; the in-class
 * `operator new(unsigned long)` forwards `_ZN7fBase_cnwEj((unsigned)size)`
 * until #2570's fBase overload lands.
 *
 * The synthesized ctor constructs the three owned subobjects below at
 * 0xd4..0x130 in declaration order; D1 destroys them in exactly the reverse
 * order before chaining to dActor_c::~dActor_c -- two independent witnesses
 * for each member's type and offset.
 *
 * Own vtable slots, from the ROM table diffed against dActor_c's: 0
 * InitResources, 3 CleanupResources, 6 Behavior, 9 Render, 12
 * OnPendingDestroy, 16/17 the destructor pair, 18 OnYoshiTryEat. Every other
 * slot is inherited.
 *
 * The header this replaces was deliberately flat -- a non-deriving struct
 * whose leading "fields" duplicated dActor_c's storage -- because giving a
 * non-derived struct a virtual would have inserted a vptr and shifted every
 * offset. Deriving from dActor_c is what makes the declarations below honest.
 */
struct daKpFr_c;
typedef void (daKpFr_c::*daKpFrStateMethod)();

struct daKpFrState {
    daKpFrStateMethod init;
    daKpFrStateMethod behavior;
};

#ifndef SM64DS_PLATFORM_PC
/* ROM layout under mwccarm; host ABI divergence is tracked separately. */
typedef char daKpFrState_size_must_be_0x10[
    sizeof(daKpFrState) == 0x10 ? 1 : -1];
#endif

struct daKpFr_c : dActor_c {
    u8                 pad_0d0[0x4];
    dExtShadowModel_c        mShadowModel;           /* 0x0d4 */
    dCcAc_c mdCcAc_c;    /* 0x0fc */
    dBgCh_Actr       mWithMeshClsn;          /* 0x130 */
    /* InitResources assigns IDENTITY_MATRIX4X3 into this slot.
       func_ov070_02121e14, called from Behavior, fills the translation and
       passes it to DropShadowRadHeight. Render does not drop the shadow. */
    Matrix4x3          mMatrix;                /* 0x2ec */
    daKpFrState       *mStateMethods;          /* 0x31c */
    s32                mStateResult;           /* 0x320 */
    /* Two particle handles, effects 0x7f and 0x80, both fed back into
       Particle::System::NewUnkCallback818 every Render, at mPosY + 0x4b000.
       [_ZN8daKpFr_c6RenderEv, now in src/game/actors/d_a_kp_fr.cpp] */
    u32                mParticle1;             /* 0x324 */
    u32                mParticle2;             /* 0x328 */
    u8                 mStateTimer;            /* 0x32c */
    u8                 pad_32d[0x3];

    /* Inline plus vtable instantiation is load-bearing: mwcc emits retail's
       D1 then D0 pair, with no homeless D2. InitResources is the first
       out-of-line virtual and anchors this TU's vtable/RTTI group. */
    virtual ~daKpFr_c() {}

    virtual s32  InitResources();       /* slot 0 */
    virtual s32  CleanupResources();    /* slot 3 */
    virtual s32  Behavior();            /* slot 6 */
    virtual s32  Render();              /* slot 9 */
    virtual void OnPendingDestroy();    /* slot 12 */
    virtual int  OnYoshiTryEat();       /* slot 18 */

    void func_ov070_02121be4();
    void func_ov070_02121c8c();
    void func_ov070_02121cbc();
    void func_ov070_02121d50(void *vclsn);
    void func_ov070_02121e14();
    int func_ov070_02121eb0();
    int func_ov070_02121ef8();
    int func_ov070_02121f18();
    int func_ov070_02121fb0();
    void func_ov070_02121fd0();
    void func_ov070_0212200c();
    void func_ov070_02122044(int idx);

    static void *operator new(size_t size) {
        return _ZN7fBase_cnwEj((unsigned)size);
    }
};

#ifndef SM64DS_PLATFORM_PC
/* ROM layout under mwccarm; host ABI divergence is tracked separately. */
typedef char daKpFr_c_size_must_be_0x330[
    sizeof(daKpFr_c) == 0x330 ? 1 : -1];
#endif

#endif /* DAKPFR_C_H */
