#ifndef DAHUWA_C_H
#define DAHUWA_C_H

#include "types.h"

/* Derives from dEnemyBase_c, and TWO INDEPENDENT WITNESSES agree on the layout: the
 * class's own destructor `_ZN8daHuwa_cD1Ev` destroys each member, and
 * `Spindrift_Spawn` constructs the same types at the same offsets before
 * storing `_ZTV8daHuwa_c`. Everything this header used to restate below 0x110
 * belongs to dEnemyBase_c and dActor_c and is inherited now.
 *
 * The members close on each other, which is what makes the layout a reading
 * rather than a guess:
 *
 *     0x110 ModelAnim                  0x64    -> 0x174
 *     0x174 dExtShadowModel_c                0x28    -> 0x19c
 *     0x19c dCcAc_c         0x34    -> 0x1d0
 *     0x1d0 dBgCh_Actr               0x1bc   -> 0x38c
 *
 * SIZE IS THE ROM'S OWN: `Spindrift_Spawn` calls `fBase_c::operator new(924)`
 * -- 0x39c -- and stores this class's vtable, so that literal IS this
 * class's sizeof.
 *
 * The ROM's RTTI names this class daHuwa_c.
 *
 * SM64DS proves this class as daHuwa_c through RTTI, allocation size and
 * vtable identity. The factory and profile spellings below are reconstructed
 * source-style names -- evidence-bounded proposals, not recovered SM64DS
 * symbols.
 *
 * daHuwa_c_classInit at 0x02124040 (historical alias Spindrift_Spawn)
 * allocates 0x39c and installs this class's cartridge vtable. It backs the
 * HUWAHUWA registry profile, whose descriptor at 0x02128858 is reconstructed
 * as g_profile_HUWAHUWA.
 */

#include "dEnemyBase_c.h"
#include "ModelAnim.h"
#include "dCcAc_c.h"
#include "dExtShadowModel_c.h"
#include "dBgCh_Actr.h"

struct daHuwa_c : dEnemyBase_c {
    ModelAnim                    mModelAnim;            /* 0x110 */
    dExtShadowModel_c                  mShadowModel;          /* 0x174 */
    dCcAc_c                      mdCcAc_c;              /* 0x19c */
    dBgCh_Actr                   mWithMeshClsn;         /* 0x1d0 */
    /* InitResources copies the spawn position here. Behavior faces it when
       there is no player, and when the player has left this radius. Three
       scalars, not a Vector3: Vector3's destructor would run from ~daHuwa_c. */
    s32                          mHomePosX;             /* 0x38c */
    s32                          mHomePosY;             /* 0x390 */
    s32                          mHomePosZ;             /* 0x394 */
    /* Yaw Behavior approaches mAngleY toward. Home, or the player. */
    s16                          mTargetAngY;           /* 0x398 */
    /* 0 chase, 1 recoil. A player bump sets 1 and counts mStateTimer to 0x14. */
    u8                           mState;                /* 0x39a */
    u8                           pad_39b[0x1];

    /* --- vtable --- */
    virtual ~daHuwa_c();

    virtual s32   OnYoshiTryEat();         /* slot 18 */
    virtual void  OnTurnIntoEgg(Player &player); /* slot 19 */
    virtual s32   OnAimedAtWithEgg();      /* slot 29 */

    /* --- non-virtual --- */
    int Behavior();
    int CleanupResources();
    int InitResources();
    int Render();
};

#ifndef SM64DS_PLATFORM_PC
/* ROM layout under mwccarm; host ABI divergence is tracked separately. */
typedef char daHuwa_c_size_must_be_0x39c[sizeof(daHuwa_c) == 0x39c ? 1 : -1];
#endif

#endif /* DAHUWA_C_H */
