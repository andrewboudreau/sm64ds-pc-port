#ifndef FBASE_C_H
#define FBASE_C_H

#include "types.h"

/* The root of the actor hierarchy. Its code is one contiguous run in arm9,
 * 0x02043444..0x02043f4c, 25 functions. The chain is fBase_c -> dBase_c ->
 * dActor_c; dActor_c is NOT a direct child of this class.
 *
 * DO NOT REORDER THE VIRTUALS -- _ZTV7fBase_c (0x02099edc) is 18 slots and slot
 * index follows declaration order. Two that are easy to get wrong: the
 * destructor is at 16/17, NOT 0/1, and vtable+0x40 (which AfterCleanupResources
 * dispatches through) is that D1 destructor, not OnPendingDestroy at slot 12.
 *
 * InitResources is the key function defined in src/runtime/actor/ActorBase.cpp.
 * Its native definition emits the class RTTI, name and complete vtable.
 * The ActorBase manifest verifies that metadata before externalizing it to
 * the existing canonical ROM storage. Keep this declaration in slot 0:
 * removing it would shift the other seventeen slots.
 *   0x02043444  is the real start: _ZN7fBase_cnwEj, this class's own
 *               operator new (size 0x50, discussed further down this file).
 *               The old 0x02043494 began at OnHeapCreated and excluded it.
 *   0x02043f4c  is the real end -- the byte after _ZN7fBase_cC2Ev, and the
 *               address of func_02043f4c, the next unrelated function.
 *   0x02043e04  was not a function boundary at all. It falls 0x18 bytes INSIDE
 *               the constructor (_ZN7fBase_cC2Ev, 0x02043dec, size 0x160), so
 *               the old end cut that function in half.
 *
 * Offsets, widths and vtable slots are pinned by the bytes; field names are not
 * and are safe to improve. The 0x34-byte manager at 0x14 owns the scene-tree
 * node and the two process-list nodes, matching both the constructor's retained
 * manager address and the later EAD engine's independently recovered fManager_c
 * organization. See notes/actor-core-provenance.md and notes/actor-vtables.md.
 */

#ifdef __cplusplus

#include "fListNode.h"

/* The actor heap and its deallocator, for the inline operator delete at the end
   of the class. data_020a0eac is the heap every actor is allocated from. Spelt
   exactly as include/decl_common.h and include/dActor_c.h spell them -- the
   honest Heap* second parameter would put two incompatible extern "C"
   declarations of one name in a single TU, which mwcc rejects. */
extern "C" void _ZN6Memory10DeallocateEPvPN5mHeap6Heap_tE(void *, void *);
extern "C" void *data_020a0eac;
/* ROM body of fBase_c::operator new(unsigned) — mangled _ZN7fBase_cnwEj.
   CW will not accept that signature as an in-class operator new (first
   parameter is not size_t). Defined in src/runtime/actor/ActorBase.cpp. */
extern "C" void *_ZN7fBase_cnwEj(unsigned size);

struct fBase_c {
    /* Intrusive scene-graph node owned by every actor. */
    struct SceneNode {
        SceneNode *parent;
        SceneNode *child;
        SceneNode *prev;
        SceneNode *next;
        fBase_c *owner;                         /* 0x10 */

        SceneNode();
        void Reset();
    };

    /* Process bookkeeping kept together as one manager subobject. */
    struct Manager {
        SceneNode sceneNode;
        fLiNdBaPr_c behaviorNode;
        fLiNdBaPr_c renderNode;

        Manager(fBase_c *owner_)
        {
            sceneNode.owner = owner_;
            {
                fLiNdBaPr_c *node = &behaviorNode;
                node->prev = 0;
                node->next = 0;
                node->owner = owner_;
                node->currentPriority = 0;
                node->nextPriority = 0;
            }
            {
                fLiNdBaPr_c *node = &renderNode;
                node->prev = 0;
                node->next = 0;
                node->owner = owner_;
                node->currentPriority = 0;
                node->nextPriority = 0;
            }
        }

        /* Both halves move together when a process enters the behavior/render
           lists. The method names are inferred; the paired writes are ROM-proven. */
        void SetBehaviorPriority(u16 priority)
        {
            fLiNdBaPr_c *node = &behaviorNode;
            node->currentPriority = priority;
            node->nextPriority = priority;
        }

        void SetRenderPriority(u16 priority)
        {
            fLiNdBaPr_c *node = &renderNode;
            node->currentPriority = priority;
            node->nextPriority = priority;
        }

    };

    /* 0x00 is the vptr, placed implicitly by the first virtual declaration. */
    u32 uniqueID;                             /* 0x04 -- post-incremented global */
    u32 param1;                               /* 0x08 */
    u16 actorID;                              /* 0x0c */
    u8  aliveState;                           /* 0x0e -- 2 means already dying */
    u8  shouldBeKilled;                       /* 0x0f */
    u8  unk_010;                              /* 0x10 */
    u8  unk_011;                              /* 0x11 */
    u8  unk_012;                              /* 0x12 */
    /* 0x13. Bit 1 pauses this object's behaviour and bit 4 hides it; bits 2 and
       8 are the effective versions, which the constructor seeds by OR-ing the
       parent's 1|2 and 4|8 down. BeforeBehavior gates on 2, BeforeRender on 8. */
    u8  pauseFlags;                           /* 0x13 */
    Manager manager;                          /* 0x14 */
    /* Optional lifecycle-operation sequence. BeforeCleanupResources waits for
       it to leave its pending state, and AfterCleanupResources drains it.
       The role is ROM-proven; the original member spelling is not. */
    void *lifecycleState;                     /* 0x48 */
    void *heap;                               /* 0x4c -- Heap*, owned */

    fBase_c();

    /* --- vtable, in _ZTV7fBase_c order. Do not reorder. --- */
    virtual s32  InitResources();                      /* slot  0 */
    virtual bool BeforeInitResources();                /* slot  1 */
    virtual void AfterInitResources(u32 vfSuccess);    /* slot  2 */
    virtual s32  CleanupResources();                   /* slot  3 */
    virtual int  BeforeCleanupResources();             /* slot  4 */
    virtual void AfterCleanupResources(u32 vfSuccess); /* slot  5 */
    virtual s32  Behavior();                           /* slot  6 */
    virtual int  BeforeBehavior();                     /* slot  7 */
    virtual void AfterBehavior(u32 vfSuccess);         /* slot  8 */
    virtual s32  Render();                             /* slot  9 */
    virtual int  BeforeRender();                       /* slot 10 */
    virtual void AfterRender(u32 vfSuccess);           /* slot 11 */
    virtual void OnPendingDestroy();                   /* slot 12 -- vtable+0x30 */
    virtual int  Virtual34(u32 a, u32 b);              /* slot 13 -- vtable+0x34 */
    virtual int  Virtual38(u32 a, u32 b);              /* slot 14 -- vtable+0x38 */
    virtual bool OnHeapCreated();                      /* slot 15 -- vtable+0x3c */
    virtual ~fBase_c();                              /* slots 16 (D1), 17 (D0) */

    /* --- non-virtual --- */
    /* Callback types follow the configured Process signature. The cleanup,
       behavior and render guards still declare int returns; their callers keep
       the existing ABI records until those guard contracts are reconciled. */
    typedef int (fBase_c::*ProcessFunction)();
    typedef bool (fBase_c::*BeforeProcessFunction)();
    typedef void (fBase_c::*AfterProcessFunction)(u32);

    int Process(ProcessFunction action, BeforeProcessFunction before,
                AfterProcessFunction after);
    void MarkForDestruction();
    /* size_t is unsigned long (`m`). The ROM allocator is operator new(unsigned)
       (`j` / _ZN7fBase_cnwEj); CW rejects that signature in-class
       ("illegal 'operator' declaration"). `return new T` binds this size_t
       overload and forwards. Not virtual, not layout. */
    static void *operator new(size_t size) {
        return _ZN7fBase_cnwEj((unsigned)size);
    }
    /* CW builds D0 (slot 17) as "run the destructor, then call operator delete".
       The inline class overload selects the actor heap at data_020a0eac. The
       global _ZdlPv exists at arm9 0x0203cbf0 but uses Memory::defaultHeapPtr. The
       deleting destructor additionally calls the actor-heap deallocator.
       This inline overload reaches only fBase_c and dBase_c --
       CW inlines it from the class itself or its IMMEDIATE base -- which is why
       include/dActor_c.h carries its own copy. */
    void operator delete(void *ptr) { _ZN6Memory10DeallocateEPvPN5mHeap6Heap_tE(ptr, data_020a0eac); }
};

#else

/* The same object for the C translation units, which cannot express the virtual
   functions, so the vptr the compiler would place is written out explicitly. */
struct fBase_c {
    void **vtable;          /* 0x00 */
    u32 uniqueID;           /* 0x04 */
    u32 param1;             /* 0x08 */
    u16 actorID;            /* 0x0c */
    u8  aliveState;         /* 0x0e */
    u8  shouldBeKilled;     /* 0x0f */
    u8  unk_010;            /* 0x10 */
    u8  unk_011;            /* 0x11 */
    u8  unk_012;            /* 0x12 */
    u8  pauseFlags;         /* 0x13 */
    u8  manager[0x34];      /* 0x14 */
    void *lifecycleState;   /* 0x48 */
    void *heap;             /* 0x4c */
};

#endif /* __cplusplus */

/* Outside the __cplusplus split on purpose, so it holds BOTH spellings to the
   same 0x50 -- the C one writes the vptr out by hand and would otherwise be free
   to drift from the C++ one. It is also what lets tools/check_header_offsets.py
   check the classes derived from this: a derived struct's own fields start at the
   base's size, and the tool refuses to guess it. */
#ifndef SM64DS_PLATFORM_PC
/* ROM layout under mwccarm; host ABI divergence is tracked separately. */
typedef char fBase_c_size_must_be_0x50[sizeof(struct fBase_c) == 0x50 ? 1 : -1];
#endif

#endif
