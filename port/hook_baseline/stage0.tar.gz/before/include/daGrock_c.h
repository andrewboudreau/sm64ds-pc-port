#ifndef DAGROCK_C_H
#define DAGROCK_C_H

#include "types.h"

/* Derives from dEnemyBase_c, on the evidence of its own destructor: `_ZN9daGrock_cD1Ev`
 * stores this vtable, destroys its members in reverse declaration order, then
 * calls `dEnemyBase_c::~dEnemyBase_c`. Everything this header used to restate below 0x110
 * belongs to that chain and is inherited now.
 *
 * The members close exactly on one another:
 *
 *     0x110 Model                      0x50   -> 0x160
 *     0x160 dExtShadowModel_c                0x28   -> 0x188
 *     0x1b8 dCcAcPos_c  0x40   -> 0x1f8
 *     0x1f8 dBgCh_Actr               0x1bc  -> 0x3b4
 *
 * Member NAMES are the ones this header already used -- a rebase should not
 * also rename things its callers spell.
 *
 * SIZE IS THE ROM'S OWN, not a rounded-up field span: `daGrock_c_classInit` calls
 * `fBase_c::operator new(968)` -- 0x3c8 -- and stores `_ZTV9daGrock_c`,
 * so that literal IS this class's sizeof. The observed fields only span to
 * 0x3c4; the difference is trailing space no source reads.
 *
 * SM64DS RTTI names the implementation daGrock_c. The reconstructed factory
 * daGrock_c_classInit (historical alias RollingRock_Spawn) installs this class's
 * cartridge vtable; the reconstructed profile global g_profile_GORO_ROCK
 * (historical alias RollingRock_SpawnInfo) is its registry descriptor.
 */

#include "dEnemyBase_c.h"
#include "Model.h"
#include "ModelAnim.h"
#include "dCcAc_c.h"
#include "dCcAcPos_c.h"
#include "dExtShadowModel_c.h"
#include "TextureTransformer.h"
#include "dBgCh_Actr.h"

struct daGrock_c : dEnemyBase_c {
    Model                        mModel;                /* 0x110 */
    dExtShadowModel_c                  mShadowModel;          /* 0x160 */
    u8  pad_188[0x30];
    dCcAcPos_c    mdCcAcPos_c; /* 0x1b8 */
    dBgCh_Actr                 mWithMeshClsn;         /* 0x1f8 */
    u32                          unk_3b4;               /* 0x3b4 */
    u8  pad_3b8[0x6];
    u8                           mType;                 /* 0x3be */
    u8                           unk_3bf;               /* 0x3bf */
    u8                           unk_3c0;               /* 0x3c0 */
    u8                           unk_3c1;               /* 0x3c1 */
    u8                           unk_3c2;               /* 0x3c2 */
    u8  pad_3c3[0x5];

    /* --- vtable --- */
    virtual ~daGrock_c();

    virtual s32   OnAimedAtWithEgg();      /* slot 29 */

    int Behavior();
    int InitResources();
    int Render();
    int CleanupResources();
};

#ifndef SM64DS_PLATFORM_PC
/* ROM layout under mwccarm; host ABI divergence is tracked separately. */
typedef char daGrock_c_size_must_be_0x3c8[sizeof(daGrock_c) == 0x3c8 ? 1 : -1];
#endif

#endif /* DAGROCK_C_H */
