/* class dScMgSmartball_c, real ROM name confirmed by tools/rtti_extract.py:
 * dScMgSmartball_c : dScMgBase_c, single edge, offset 0 (build/rtti.json).
 * Its own vtable is ov006:0x0213eefc; the RTTI pointer one word below it is
 * _ZTI16dScMgSmartball_c. The LAST direct child of dScMgBase_c to become a
 * real class -- with this, every RTTI descendant of dScMgBase_c is one.
 *
 * A DIRECT child, with no intermediate: its own D1 stores this class's
 * vtable, destroys the four arrays, and calls _ZN11dScMgBase_cD2Ev
 * straight away -- no second vptr store, which is what an inlined
 * intermediate base's destructor would have left behind.
 *
 * SIZE 0x629c, from dScMgSmartball_c_classInit's own
 * `_ZN7fBase_cnwEj(0x629c)`, and the last array closes EXACTLY on it:
 * 0x599c + 0x40 * 0x24 = 0x629c. The coined English _Spawn name
 * MgBingoBallSlotsShot_Spawn is already attributed and is retained as a
 * historical alias, the same convention as dScMgCard_c_classInit
 * (historical alias MgPicturePoker_Spawn) for dScMgCard_c.
 *
 * FACTORY AND DESTRUCTOR AGREE MEMBER FOR MEMBER, in exact reverse order:
 * built 0x47c8, 0x4854, 0x48d4, 0x599c; destroyed 0x599c, 0x48d4, 0x4854,
 * 0x47c8. Nothing is left over either way. Three of the four share an
 * element ctor/dtor pair (func_0203d738 / NullDestructor_0203d47c) so they
 * are the same element type as each other; mArray4's is its own
 * (SmartballObj_ElemCtor / SmartballObj_ElemDtor).
 *
 * THE PADS HERE ARE NOT UNREAD SPACE, AND THIS FILE WILL NOT PRETEND THEY
 * ARE. A scan of this class's own seven recovered methods -- checked for
 * split-literal forms as well as whole constants -- finds 45 distinct
 * offsets between 0x4660 and 0x629c, thirteen of them inside pad_4954
 * alone. They are real matched access; they are simply not modelled yet,
 * because each one's WIDTH has to come from its access site and that is a
 * separate reading pass from making the class real. Naming them changes no
 * byte and needs no migration -- each of those methods reaches
 * them by raw offset today and will keep working untouched.
 *
 * So: the four arrays below are evidenced by two witnesses each and the
 * size is evidenced by a third. Everything else is honest padding-for-now,
 * not a claim that nothing reads it.
 *
 * THE DESTRUCTOR IS NOT DEFINED INLINE -- a leaf, no RTTI descendants of
 * its own. Its definition in src/minigames/d_s_mg_smartball.cpp emits both
 * destructor variants. No separate operator delete is needed --
 * dScMgBase_c, the immediate base, already provides one.
 *
 * SM64DS RTTI names the implementation dScMgSmartball_c. The reconstructed factory
 * dScMgSmartball_c_classInit (historical alias MgBingoBallSlotsShot_Spawn) installs this class's
 * cartridge vtable for the MG_SMARTBALL registry profile.
 */
#ifndef DSCMGSMARTBALL_C_H
#define DSCMGSMARTBALL_C_H
#include "dScMgBase_c.h"

extern "C" void __cxa_vec_cleanup(void *base, int count, int stride, void *dtor);
extern "C" void NullDestructor_0203d47c(void);
extern "C" void SmartballObj_ElemDtor(void);

struct dScMgSmartball_c : dScMgBase_c {
    virtual ~dScMgSmartball_c();

    /* This class's own overrides, read off the ROM's vtable: the slots where the
       table differs from dScMgBase_c's. Spelled WITHOUT the `virtual` keyword, the
       way include/daObjMarioCap_c.h and include/daObjRc_Dorifu_c.h spell theirs --
       an override of a virtual an ancestor already declares is implicitly virtual
       either way, so each reuses an existing slot and adds no field, and the
       0x629c assert below still holds. The destructor above is declared first and
       out of line, so it stays this class's key function; the production TU owns the
       compiler-emitted vtable.

       AfterCleanupResources takes dScMgBase_c's signature exactly, u32 and all.
       The pre-migration file spelled the parameter `int mode` and still matched,
       because the ROM only ever compares it against 2 -- but the declaration it is
       overriding is `void AfterCleanupResources(u32)`, so that is what it is. */
    /* InitResources was declared here before its body existed, because the
       EMITTED vtable needs the declaration: without it mwcc wrote fBase_c's
       default, _ZN7fBase_c13InitResourcesEv (0x02043c80), into slot 0 while the
       cartridge holds 0x02118b70 -- romdata_check scored _ZTV16dScMgSmartball_c
       DIFFERS on that one word. Its 0x8dc bytes are now decompiled and enrolled
       (src/minigames/d_s_mg_smartball.cpp); the slot is unchanged. */
    virtual void StartRound(int arg);               /* slot 18 */
    virtual int  OnGraphCallback3();                           /* slot 25 */
    virtual int  InitSubScreenBg();                          /* slot 31 */
    s32  InitResources();  /* slot  0 */
    void AfterCleanupResources(u32 vfSuccess);
                           /* slot  5 */
    s32  Behavior();       /* slot  6 */
    s32  Render();         /* slot  9 */

    /* Recovered helpers. The spark/dust pair renders the rolling-ball trail
       and the collision poofs; the Count* counters feed the score popup the
       emitter queue plays back; EmitScore is the 5-slot popup queue. */
    int  SparksActive();
    void EmitSparks(int *pair, int a3);
    void RenderSparks();
    void UpdateSparks();
    void ResetSparks();
    void EndRound();
    void ServeNextBall();
    void CountOut();
    void CountAward(int i);
    void CountDokan();
    void CountAna();
    void CountKinoko();
    void CountBingo();
    int  CountLine(int i);
    void CountCell();
    unsigned short GetTile(int *pos);
    void UpdateDust();
    void SpawnDust(int *origin);
    void UpdateScores();
    void EmitScore(int *src, int v2, int v3, int v5);
    void KickGate(int idx);
    int  IsTableAtRest();
    void ResolveBallPair(int b, int c, u8 *d, u8 *e);
    void CollideBalls();
    void SpawnObjects();

    u8 pad_4660[0x168];   /* 0x4660 -- dScMgBase_c's data ends here; real matched
                              access inside, see file banner */
    u8 mArray1[0x28];     /* 0x47c8 -- 5 * 8,      elem dtor NullDestructor_0203d47c */
    u8 pad_47f0[0x64];    /* 0x47f0 -- real matched access, see file banner */
    u8 mArray2[0x80];     /* 0x4854 -- 0x10 * 8,   elem dtor NullDestructor_0203d47c */
    u8 mArray3[0x80];     /* 0x48d4 -- 0x10 * 8,   elem dtor NullDestructor_0203d47c */
    u8 pad_4954[0x1048];  /* 0x4954 -- real matched access (13 offsets), see banner */
    u8 mArray4[0x900];    /* 0x599c -- 0x40 * 0x24, elem dtor SmartballObj_ElemDtor */
};

#ifndef SM64DS_PLATFORM_PC
/* ROM layout under mwccarm; host ABI divergence is tracked separately. */
typedef char dScMgSmartball_c_size_must_be_0x629c[sizeof(dScMgSmartball_c) == 0x629c ? 1 : -1];
#endif

#endif
