#ifndef DAPEACH_C_H
#define DAPEACH_C_H

#include "dActor_c.h"
#include "ModelAnim.h"
#include "dExtShadowModel_c.h"
#include "dCcAc_c.h"
#include "dBgCh_Actr.h"

struct Player;

/* The cartridge RTTI names this class daPeach_c: the word at 0x0212ffbc loads
 * the __si_class_type_info record at 0x0212ff90, whose name string at
 * 0x0212ff84 reads `9daPeach_c`. The tree previously coined it `PrincessPeach`.
 * That record points directly at dActor_c at offset zero, and its vtable has
 * the same 31 slots as that base's table.
 *
 * The five state pairs below are not inferred from address adjacency. Ten
 * eight-byte ROM PMF constants at 0x0212ff34..0x0212ff83 are copied into
 * data_ov085_0213055c. SetState selects one pair and calls its first member;
 * Behavior calls the second member. The descriptive helper names are useful
 * source names, not names authenticated by the cartridge.
 *
 * SM64DS proves this class as daPeach_c through RTTI, allocation size and
 * vtable identity. The factory and profile spellings below are reconstructed
 * source-style names -- evidence-bounded proposals, not recovered SM64DS
 * symbols.
 *
 * daPeach_c_classInit at 0x0212a684 (historical alias PrincessPeach_Spawn)
 * allocates 0x36c and installs this class's cartridge vtable. It backs the
 * PEACH_PRINCESS registry profile, whose descriptor at 0x0212ff9c is
 * reconstructed as g_profile_PEACH_PRINCESS.
 */
struct daPeach_c : dActor_c {
    u8 mPad0d0[0x4];                    /* 0x0d0 */
    ModelAnim mModelAnim;               /* 0x0d4 */
    dExtShadowModel_c mShadowModel;           /* 0x0138 */
    dCcAc_c mCylinder;                  /* 0x0160 */
    dBgCh_Actr mWithMeshClsn;           /* 0x0194 */

    typedef int (daPeach_c::*StateFunc)();
    StateFunc *mStateFuncs;             /* 0x0350 */
    s32 mStateValue;                    /* 0x0354 */
    u32 unk_358;                        /* 0x0358 */
    Player *mTalkPlayer;                /* 0x035c */
    s16 mLookVertAngle;                 /* 0x0360 */
    s16 mLookHorzAngle;                 /* 0x0362 */
    s16 mTargetLookVertAngle;           /* 0x0364 */
    s16 mTargetLookHorzAngle;           /* 0x0366 */
    u8 mTalkState;                      /* 0x0368 */
    u8 mPad369[0x3];                    /* 0x0369 */

    /* Inline is load-bearing: forcing translation units emit the genuine D1
     * and D0 without introducing a homeless D2 definition. */
    virtual ~daPeach_c() {}

    virtual int InitResources();        /* slot  0 */
    virtual int CleanupResources();     /* slot  3 */
    virtual int Behavior();             /* slot  6 */
    virtual int Render();               /* slot  9 */
    virtual void OnPendingDestroy();    /* slot 12 */

    int InitState0();
    int State0();
    int InitState1();
    int State1();
    int InitState2();
    int State2();
    int InitState3();
    int State3();
    int InitState4();
    int State4();

    void UpdateLookAt();
    void UpdateGroundCollision(dBgCh_Actr *collision);
    /* The owned player-contact query at 0x02129f8c remains the C symbol
     * func_ov085_02129f8c. In C++ mode the same source either drops the ROM's
     * final redundant compare or re-normalizes the already-0/1 result, moving
     * the body by one or two words; no source-level exact form is known. */
    void UpdateModel();
    void CallStateBehavior();
    void CallStateInit();
    void SetState(int state);
};

#ifndef SM64DS_PLATFORM_PC
/* ROM layout under mwccarm; host ABI divergence is tracked separately. */
typedef char daPeach_c_size_must_be_0x36c[
    sizeof(daPeach_c) == 0x36c ? 1 : -1];
#endif

#endif
